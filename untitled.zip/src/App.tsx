/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { KineticMarquee } from './components/KineticMarquee';
import { RecentWorkRepository } from './components/RecentWorkRepository';
import { SelectedWork } from './components/SelectedWork';
import { TimelineInspector } from './components/TimelineInspector';
import { WorkflowSection } from './components/WorkflowSection';
import { ToolkitSection } from './components/ToolkitSection';
import { AboutSection } from './components/AboutSection';
import { InquirySection } from './components/InquirySection';
import { Footer } from './components/Footer';
import { VideoModal } from './components/VideoModal';
import { VideoProject } from './data/projects';

export default function App() {
  const [activeProject, setActiveProject] = useState<VideoProject | null>(null);
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('mohit_theme');
      if (saved === 'light' || saved === 'dark') return saved;
    }
    return 'dark';
  });

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('mohit_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleBookClick = () => {
    const contactElem = document.getElementById('contact');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleExploreWork = () => {
    const recentElem = document.getElementById('recent');
    if (recentElem) {
      recentElem.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#090A0D] text-slate-900 dark:text-[#ECEAE5] selection:bg-[#D97706] selection:text-white dark:selection:bg-[#E5A93C] dark:selection:text-[#0B0C0E] flex flex-col font-sans transition-colors duration-200">
      {/* 3-Zone Top Navigation Bar with High-Contrast Theme Switcher */}
      <Navbar 
        onBookClick={handleBookClick} 
        theme={theme}
        onToggleTheme={toggleTheme}
      />

      <main className="flex-1">
        {/* Split-Screen Hero with 2-Second Auto-Reel & Giant Animating Text */}
        <Hero
          onPlayFeatured={(project) => setActiveProject(project)}
          onExploreWork={handleExploreWork}
        />

        {/* Very Large Animating Text Marquee (Mohit Singh) */}
        <KineticMarquee />

        {/* Recent Work Repository: All 8 Drive Videos One-by-One */}
        <RecentWorkRepository
          onOpenTheatre={(project) => setActiveProject(project)}
        />

        {/* Selected Work Catalogue (V1: Shorts 9:16, V2: Gyani Brothers, V3: Programming Guruji) */}
        <SelectedWork
          onPlayProject={(project) => setActiveProject(project)}
        />

        {/* Interactive Multi-Track NLE Timeline Sequence */}
        <TimelineInspector
          onPlayProject={(project) => setActiveProject(project)}
          activeProject={activeProject}
        />

        {/* 5-Step Post-Production Workflow Pipeline */}
        <WorkflowSection />

        {/* Software Toolkit & 3-Column Media Bin */}
        <ToolkitSection />

        {/* About Mohit & Pedagogical Editing Background */}
        <AboutSection />

        {/* Project Scope Configurator & Inquiry Booking */}
        <InquirySection />
      </main>

      {/* Footer */}
      <Footer />

      {/* In-App Video Screening Suite & Theater Modal */}
      <VideoModal
        project={activeProject}
        onClose={() => setActiveProject(null)}
        onSelectProject={(project) => setActiveProject(project)}
      />
    </div>
  );
}
