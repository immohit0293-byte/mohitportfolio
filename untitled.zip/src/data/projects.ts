export interface VideoProject {
  id: string;
  projectNumber: string;
  title: string;
  subtitle: string;
  trackId: 'V1' | 'V2' | 'V3' | 'DRIVE';
  trackName: string;
  trackColor: string;
  trackDescription: string;
  ratio: '9:16' | '16:9';
  source: 'youtube' | 'drive';
  youtubeId?: string;
  driveId?: string;
  fileName?: string;
  embedUrl: string;
  directUrl: string;
  thumbnail: string;
  fallbackThumbnail?: string;
  duration: string;
  cutsEstimate: string;
  targetPlatform: string;
  description: string;
  editHighlights: string[];
  toolsUsed: string[];
  keyTechniques: {
    hook: string;
    pacing: string;
    audio: string;
    visuals: string;
  };
  socialManagerStrategy?: {
    objective: string;
    targetAudience: string;
    retentionTactic: string;
    ctaGoal: string;
  };
}

/**
 * All verified video cuts from Mohit Singh's shared Google Drive Repository:
 * https://drive.google.com/drive/folders/1_Wf572H12tyfZ___oytTclg_EfU7Ep_H?usp=sharing
 * Showcasing recent work as a Social Media Manager & Video Editor.
 */
export const DRIVE_FOLDER_VIDEOS: VideoProject[] = [
  {
    id: 'drive-7068',
    projectNumber: 'DRIVE 01',
    fileName: 'Video-7068.mp4',
    title: 'High-Retention Social Hook — Cut 7068',
    subtitle: 'Social Media Management & Algorithm Pacing',
    trackId: 'DRIVE',
    trackName: 'Drive Repository · Social Media Cut',
    trackColor: '#E5A93C',
    trackDescription: 'Recent Drive Master · Social Media Manager Portfolio',
    ratio: '9:16',
    source: 'drive',
    driveId: '1IarXMOhdCsNeZxKx29HPUX6PgXCf8Hjc',
    embedUrl: 'https://drive.google.com/file/d/1IarXMOhdCsNeZxKx29HPUX6PgXCf8Hjc/preview',
    directUrl: 'https://drive.google.com/file/d/1IarXMOhdCsNeZxKx29HPUX6PgXCf8Hjc/view',
    thumbnail: 'https://lh3.googleusercontent.com/d/1IarXMOhdCsNeZxKx29HPUX6PgXCf8Hjc=w640',
    fallbackThumbnail: 'https://drive.google.com/thumbnail?id=1IarXMOhdCsNeZxKx29HPUX6PgXCf8Hjc&sz=w640',
    duration: '0:38',
    cutsEstimate: '22 cuts · 1.6s avg',
    targetPlatform: 'Instagram Reels & YouTube Shorts',
    description: 'High-velocity vertical video engineered for Instagram Reels and Shorts. Features dynamic text pop-ins designed for the 80%+ mobile audience watching without audio, synchronized with punchy sound effects for full-engagement listeners.',
    editHighlights: [
      'Engineered an immediate 1.5-second curiosity hook to prevent scrolling',
      'Word-by-word animated subtitles formatted within mobile safe-zones',
      'Micro-punch zooms at key punchlines and transition points',
      'High-contrast color grading ensuring visibility on mobile phone displays'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'CapCut Pro', 'Audacity'],
    keyTechniques: {
      hook: 'Immediate visual movement and bold keyword overlay in frame 1',
      pacing: '1.6-second cut frequency matching fast social media consumption habits',
      audio: 'Dialogue clarity boosting + crisp whooshes and pop SFX',
      visuals: '9:16 vertical frame with top/bottom UI margin clearance'
    },
    socialManagerStrategy: {
      objective: 'Brand Discovery & High-Velocity Reach',
      targetAudience: 'Mobile Gen Z & Young Professionals on Instagram/Shorts',
      retentionTactic: 'Dynamic keyword pacing preventing drop-off at second 3',
      ctaGoal: 'Profile click-through and save/share actions'
    }
  },
  {
    id: 'drive-11620',
    projectNumber: 'DRIVE 02',
    fileName: 'Video-11620.mp4',
    title: 'Audience Engagement & Community Reel — Cut 11620',
    subtitle: 'Conversational Pacing & Narrative Hook',
    trackId: 'DRIVE',
    trackName: 'Drive Repository · Social Media Cut',
    trackColor: '#5FA8A0',
    trackDescription: 'Recent Drive Master · Social Media Manager Portfolio',
    ratio: '9:16',
    source: 'drive',
    driveId: '1z5jkxOyevWk9hPux6inaoh4Z8Vaq5wa4',
    embedUrl: 'https://drive.google.com/file/d/1z5jkxOyevWk9hPux6inaoh4Z8Vaq5wa4/preview',
    directUrl: 'https://drive.google.com/file/d/1z5jkxOyevWk9hPux6inaoh4Z8Vaq5wa4/view',
    thumbnail: 'https://lh3.googleusercontent.com/d/1z5jkxOyevWk9hPux6inaoh4Z8Vaq5wa4=w640',
    fallbackThumbnail: 'https://drive.google.com/thumbnail?id=1z5jkxOyevWk9hPux6inaoh4Z8Vaq5wa4&sz=w640',
    duration: '0:42',
    cutsEstimate: '25 cuts · 1.7s avg',
    targetPlatform: 'Instagram Reels & YouTube Shorts',
    description: 'Community-building short designed to trigger comments and debate. Scripted and edited with strategic pattern interrupts to maintain attention all the way to the call-to-action.',
    editHighlights: [
      'Strategic visual pattern interrupts every 3.5 seconds',
      'Dual-color highlight subtitle styling for emphasis keywords',
      'Normalized vocal track with background ambient music ducked by -18dB',
      'Seamless loop outro connecting the closing remark directly back to the opener'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'VN Editor', 'Audacity'],
    keyTechniques: {
      hook: 'Direct-to-camera eye contact with provocative opening inquiry',
      pacing: 'Tight rhythm removing breath pauses without feeling robotic',
      audio: 'High-pass vocal EQ + subtle click SFX on text animations',
      visuals: 'Contrast-enhanced skin tones and crisp graphic badges'
    },
    socialManagerStrategy: {
      objective: 'Comment Generation & Community Engagement',
      targetAudience: 'Active followers and algorithm exploration feeds',
      retentionTactic: 'Posing an engaging question and visual contrast shifts',
      ctaGoal: 'Prompting viewer comments to signal engagement to the algorithm'
    }
  },
  {
    id: 'drive-28061',
    projectNumber: 'DRIVE 03',
    fileName: 'Video-28061.mp4',
    title: 'Product Spotlight & Conversion Cut — Cut 28061',
    subtitle: 'Direct-Response Creative & Micro-Tutorial',
    trackId: 'DRIVE',
    trackName: 'Drive Repository · Social Media Cut',
    trackColor: '#C97B63',
    trackDescription: 'Recent Drive Master · Social Media Manager Portfolio',
    ratio: '9:16',
    source: 'drive',
    driveId: '1x7hVMwj3zspHpZ9VI-tD_tsFSNCtU3vE',
    embedUrl: 'https://drive.google.com/file/d/1x7hVMwj3zspHpZ9VI-tD_tsFSNCtU3vE/preview',
    directUrl: 'https://drive.google.com/file/d/1x7hVMwj3zspHpZ9VI-tD_tsFSNCtU3vE/view',
    thumbnail: 'https://lh3.googleusercontent.com/d/1x7hVMwj3zspHpZ9VI-tD_tsFSNCtU3vE=w640',
    fallbackThumbnail: 'https://drive.google.com/thumbnail?id=1x7hVMwj3zspHpZ9VI-tD_tsFSNCtU3vE&sz=w640',
    duration: '0:48',
    cutsEstimate: '28 cuts · 1.7s avg',
    targetPlatform: 'Instagram Reels & Social Ads',
    description: 'Direct-response social media creative demonstrating high-clarity value propositions. Mastered with on-screen pointers, split-screen comparisons, and conversion-focused framing.',
    editHighlights: [
      'Problem-Agitate-Solve framework paced within 48 seconds',
      'Animated pointer graphics highlighting key value features',
      'Clean audio mix eliminating background rumble and microphone pops',
      'High-contrast call-to-action end card optimized for bio link clicks'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'CapCut Pro', 'Photoshop'],
    keyTechniques: {
      hook: 'Pain point visualization displayed within the opening 2 seconds',
      pacing: 'Rapid demonstration cadence keeping viewers curious',
      audio: 'Rhythmic bass drops marking product feature highlights',
      visuals: 'Spotlight highlights on key screen elements'
    },
    socialManagerStrategy: {
      objective: 'Lead Generation & Click-Through Conversion',
      targetAudience: 'Warm audience and social media ad traffic',
      retentionTactic: 'Progressive benefit disclosure sustaining watch time',
      ctaGoal: 'Directing viewers to tap link in bio or send DM'
    }
  },
  {
    id: 'drive-35400',
    projectNumber: 'DRIVE 04',
    fileName: 'Video-35400.mp4',
    title: 'Trend-Driven Narrative & Sound Sync — Cut 35400',
    subtitle: 'Viral Audio Timing & Visual Rhythm',
    trackId: 'DRIVE',
    trackName: 'Drive Repository · Social Media Cut',
    trackColor: '#9B8CD9',
    trackDescription: 'Recent Drive Master · Social Media Manager Portfolio',
    ratio: '9:16',
    source: 'drive',
    driveId: '1Rj43_BQjWNdK4Wo0diZDVG2rU67htw3h',
    embedUrl: 'https://drive.google.com/file/d/1Rj43_BQjWNdK4Wo0diZDVG2rU67htw3h/preview',
    directUrl: 'https://drive.google.com/file/d/1Rj43_BQjWNdK4Wo0diZDVG2rU67htw3h/view',
    thumbnail: 'https://lh3.googleusercontent.com/d/1Rj43_BQjWNdK4Wo0diZDVG2rU67htw3h=w640',
    fallbackThumbnail: 'https://drive.google.com/thumbnail?id=1Rj43_BQjWNdK4Wo0diZDVG2rU67htw3h&sz=w640',
    duration: '0:35',
    cutsEstimate: '24 cuts · 1.4s avg',
    targetPlatform: 'Instagram Reels, TikTok & Shorts',
    description: 'Fast-cut narrative edit synchronized to trending audio beats. Capitalizes on platform algorithmic preference for tight beat matching and rhythmic motion transitions.',
    editHighlights: [
      'Frame-accurate beat cuts synchronized to underlying audio BPM',
      'Kinetic motion blur transitions between location/angle changes',
      'Dynamic typography with glowing accent color highlights',
      'Optimized for repeated loops to amplify algorithmic watch time'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'CapCut Pro', 'VN Editor'],
    keyTechniques: {
      hook: 'Fast auditory sound riser matched to instant camera push-in',
      pacing: '1.4s average cut pace for maximum sensory engagement',
      audio: 'Carefully mastered beat drops and transition swooshes',
      visuals: 'Multi-angle quick cuts giving high production value'
    },
    socialManagerStrategy: {
      objective: 'Viral Distribution & Audio Trend Capitalization',
      targetAudience: 'Broad explore page and algorithm discovery feeds',
      retentionTactic: 'Over 100% average watch time via seamless looping',
      ctaGoal: 'Follow for part 2 / follow for daily updates'
    }
  },
  {
    id: 'drive-44326',
    projectNumber: 'DRIVE 05',
    fileName: 'Video-44326.mp4',
    title: 'Educational Growth Short — Cut 44326',
    subtitle: 'Knowledge Bite & Authority Building',
    trackId: 'DRIVE',
    trackName: 'Drive Repository · Social Media Cut',
    trackColor: '#E5A93C',
    trackDescription: 'Recent Drive Master · Social Media Manager Portfolio',
    ratio: '9:16',
    source: 'drive',
    driveId: '1dlTycnWRy7Wq5ii-HQ0U9AXb591RqLTK',
    embedUrl: 'https://drive.google.com/file/d/1dlTycnWRy7Wq5ii-HQ0U9AXb591RqLTK/preview',
    directUrl: 'https://drive.google.com/file/d/1dlTycnWRy7Wq5ii-HQ0U9AXb591RqLTK/view',
    thumbnail: 'https://lh3.googleusercontent.com/d/1dlTycnWRy7Wq5ii-HQ0U9AXb591RqLTK=w640',
    fallbackThumbnail: 'https://drive.google.com/thumbnail?id=1dlTycnWRy7Wq5ii-HQ0U9AXb591RqLTK&sz=w640',
    duration: '0:55',
    cutsEstimate: '32 cuts · 1.7s avg',
    targetPlatform: 'Instagram Reels & YouTube Shorts',
    description: 'Educational authority reel translating complex training concepts into digestible 55-second micro-learning clips. Designed to position creator as an industry expert.',
    editHighlights: [
      'Step-by-step numbered breakdown keeping viewers oriented',
      'Visual diagram insets overlaid on presenter A-roll',
      'Studio vocal warmth and de-essing for crystal clarity',
      'Saveable reference checklist prompting bookmark saves'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'Photoshop', 'Audacity'],
    keyTechniques: {
      hook: 'Bold on-screen title stating the 3 key secrets revealed',
      pacing: 'Steady, rhythmically rewarding cadence without dragging',
      audio: 'Crisp broadcast-style vocal presence',
      visuals: 'Minimalist graphic overlays with soft dropshadows'
    },
    socialManagerStrategy: {
      objective: 'Account Authority & Save/Bookmark Rate',
      targetAudience: 'Learners, students, and professionals',
      retentionTactic: 'Numbering steps (1, 2, 3) so viewers stay to see all 3',
      ctaGoal: 'Prompting users to save this post for future reference'
    }
  },
  {
    id: 'drive-44675',
    projectNumber: 'DRIVE 06',
    fileName: 'Video-44675.mp4',
    title: 'Brand Storytelling & Retainer Cut — Cut 44675',
    subtitle: 'Social Identity & High-Polish Master',
    trackId: 'DRIVE',
    trackName: 'Drive Repository · Social Media Cut',
    trackColor: '#5FA8A0',
    trackDescription: 'Recent Drive Master · Social Media Manager Portfolio',
    ratio: '9:16',
    source: 'drive',
    driveId: '1uRTwCxAQShThvxWTI77IchE4Z5ELo5Jk',
    embedUrl: 'https://drive.google.com/file/d/1uRTwCxAQShThvxWTI77IchE4Z5ELo5Jk/preview',
    directUrl: 'https://drive.google.com/file/d/1uRTwCxAQShThvxWTI77IchE4Z5ELo5Jk/view',
    thumbnail: 'https://lh3.googleusercontent.com/d/1uRTwCxAQShThvxWTI77IchE4Z5ELo5Jk=w640',
    fallbackThumbnail: 'https://drive.google.com/thumbnail?id=1uRTwCxAQShThvxWTI77IchE4Z5ELo5Jk&sz=w640',
    duration: '0:45',
    cutsEstimate: '26 cuts · 1.7s avg',
    targetPlatform: 'Instagram Reels & YouTube Shorts',
    description: 'Polished brand social edit with cinematic color curves, seamless B-roll blending, and punchy audio mastering that elevates client content above amateur competitors.',
    editHighlights: [
      'Rec.709 color grade balancing skin tones and vibrant surroundings',
      'J-cuts and L-cuts smoothing transitions between scenes',
      'Vocal presence EQ tuned to cut through smartphone speakers',
      'Branded watermark and outro card integrated seamlessly'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'CapCut Pro', 'Audacity'],
    keyTechniques: {
      hook: 'High-contrast opening frame with kinetic typography',
      pacing: 'Dynamic balance between fast cuts and breathing room',
      audio: 'Full frequency balance with -14 LUFS loudness mastering',
      visuals: 'Cinematic wide/tight framing alternation'
    },
    socialManagerStrategy: {
      objective: 'Brand Credibility & Client Retainer Showcasing',
      targetAudience: 'B2B clients, creative directors, and prospective partners',
      retentionTactic: 'High visual aesthetics signaling premium craft',
      ctaGoal: 'Inquiry dispatch and portfolio navigation'
    }
  },
  {
    id: 'drive-proj01',
    projectNumber: 'DRIVE 07',
    fileName: 'Project-01-Short.mp4',
    title: 'Fast-Paced Retention Reel — Short Edit #01',
    subtitle: 'Hook Architecture & Sound Design Master',
    trackId: 'DRIVE',
    trackName: 'Drive Repository · Social Media Cut',
    trackColor: '#E5A93C',
    trackDescription: 'Self-shot · Self-edited · Social retention',
    ratio: '9:16',
    source: 'drive',
    driveId: '1wFuQcpsC5HtIekGkF5lX0PM_xPkhpc0a',
    embedUrl: 'https://drive.google.com/file/d/1wFuQcpsC5HtIekGkF5lX0PM_xPkhpc0a/preview',
    directUrl: 'https://drive.google.com/file/d/1wFuQcpsC5HtIekGkF5lX0PM_xPkhpc0a/view',
    thumbnail: 'https://lh3.googleusercontent.com/d/1wFuQcpsC5HtIekGkF5lX0PM_xPkhpc0a=w640',
    fallbackThumbnail: 'https://drive.google.com/thumbnail?id=1wFuQcpsC5HtIekGkF5lX0PM_xPkhpc0a&sz=w640',
    duration: '0:45',
    cutsEstimate: '26 cuts · 1.7s avg',
    targetPlatform: 'Instagram Reels & YouTube Shorts',
    description: 'Vertical short cut crafted for Instagram & YouTube, edited for an immediate 2-second hook, tight rhythmic jump cuts, kinetic captions, and scroll-stopping retention.',
    editHighlights: [
      'Engineered initial 1.8s audio riser hook to arrest scrolling',
      'Dynamic single-word highlighted subtitle animations',
      'Micro-punch zooms at key comedic & instructional beats',
      'Background ambient audio ducked by -18dB under speech'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'CapCut Pro', 'Audacity'],
    keyTechniques: {
      hook: 'Curiosity gap with instant visual movement in frame 1',
      pacing: '1.7s average cut duration with zero dead silence',
      audio: 'High-pass filter on dialogue + pop whoosh sound effects',
      visuals: '9:16 vertical framing with top/bottom safe zone optimization'
    },
    socialManagerStrategy: {
      objective: 'Maximum Organic Retention Rate',
      targetAudience: 'Instagram explore feed & Shorts shelf',
      retentionTactic: 'Dynamic kinetic captions maintaining focus',
      ctaGoal: 'Channel subscriber and profile conversion'
    }
  },
  {
    id: 'drive-proj02',
    projectNumber: 'DRIVE 08',
    fileName: 'Project-02-Short.mp4',
    title: 'Micro-Tutorial & Looping Narrative — Short Edit #02',
    subtitle: 'Paced Education & Seamless Loop Hook',
    trackId: 'DRIVE',
    trackName: 'Drive Repository · Social Media Cut',
    trackColor: '#C97B63',
    trackDescription: 'Self-shot · Self-edited · Social retention',
    ratio: '9:16',
    source: 'drive',
    driveId: '1knr4cPev1gYpezUEBp7qFcrtJR6lK5J0',
    embedUrl: 'https://drive.google.com/file/d/1knr4cPev1gYpezUEBp7qFcrtJR6lK5J0/preview',
    directUrl: 'https://drive.google.com/file/d/1knr4cPev1gYpezUEBp7qFcrtJR6lK5J0/view',
    thumbnail: 'https://lh3.googleusercontent.com/d/1knr4cPev1gYpezUEBp7qFcrtJR6lK5J0=w640',
    fallbackThumbnail: 'https://drive.google.com/thumbnail?id=1knr4cPev1gYpezUEBp7qFcrtJR6lK5J0&sz=w640',
    duration: '0:52',
    cutsEstimate: '29 cuts · 1.8s avg',
    targetPlatform: 'Instagram Reels & YouTube Shorts',
    description: 'Second vertical short in the series — trimmed, captioned, and paced for high completion rate. Features graphic callouts and clean seamless loop structure.',
    editHighlights: [
      'Seamless loop transition where final sentence flows into beginning',
      'On-screen icon pop-ins synchronized to voice emphasis',
      'Studio vocal EQ for punchy presence on mobile phone speakers',
      'Color curve balance to ensure skin tones remain natural on OLED displays'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'VN Video Editor', 'Audacity'],
    keyTechniques: {
      hook: 'Problem statement posed within 1.5 seconds',
      pacing: 'Progressive disclosure rhythm with graphic reinforcement',
      audio: 'Carefully timed UI click and transition whoosh cues',
      visuals: 'Contrast-enhanced overlay text with subtle drop shadows'
    },
    socialManagerStrategy: {
      objective: 'Completion Rate Optimization (>85% completion)',
      targetAudience: 'Tech enthusiasts and digital creators',
      retentionTactic: 'Circular sentence structure creating endless loop',
      ctaGoal: 'Share with friends & bookmark for reference'
    }
  }
];

export const VIDEO_PROJECTS: VideoProject[] = [
  ...DRIVE_FOLDER_VIDEOS,
  {
    id: 'proj-03',
    projectNumber: 'PROJECT 03',
    title: 'Gyani Brothers — Episode 01',
    subtitle: 'Channel Production, Multi-Take Sync & Pacing',
    trackId: 'V2',
    trackName: 'Gyani Brothers — Long-form',
    trackColor: '#5FA8A0',
    trackDescription: 'Self audio/video · Self-edited · Commentary & entertainment',
    ratio: '16:9',
    source: 'youtube',
    youtubeId: 'n6-o1nj6dsM',
    embedUrl: 'https://www.youtube.com/embed/n6-o1nj6dsM?autoplay=1&rel=0',
    directUrl: 'https://www.youtube.com/watch?v=n6-o1nj6dsM',
    thumbnail: 'https://img.youtube.com/vi/n6-o1nj6dsM/maxresdefault.jpg',
    fallbackThumbnail: 'https://img.youtube.com/vi/n6-o1nj6dsM/hqdefault.jpg',
    duration: '14:20',
    cutsEstimate: '110+ cuts · Narrative flow',
    targetPlatform: 'YouTube Channel (16:9 Widescreen)',
    description: 'Full long-form edit for Gyani Brothers: raw unscripted footage cut down into a cohesive narrative with synced dialogue, comedic crash zooms, and custom graphic lower thirds.',
    editHighlights: [
      'Multi-track audio cleanup reducing room echo and leveling dual mics',
      'Visual re-anchors every 15-20 seconds to prevent audience drop-off',
      'Thematic lower thirds and chapter cards',
      'Dynamic B-roll inserts reinforcing talking points'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'Photoshop', 'Filmora', 'Audacity'],
    keyTechniques: {
      hook: 'Curated 10-second cold open montage of the episode highlights',
      pacing: 'L-cuts and J-cuts for natural conversational cadence',
      audio: 'Two-channel audio mastering to YouTube standard -14 LUFS',
      visuals: 'Custom brand color grading with saturated accent pop'
    }
  },
  {
    id: 'proj-04',
    projectNumber: 'PROJECT 04',
    title: 'Gyani Brothers — Episode 02',
    subtitle: 'Self-Shot & End-to-End Post-Production',
    trackId: 'V2',
    trackName: 'Gyani Brothers — Long-form',
    trackColor: '#5FA8A0',
    trackDescription: 'Self audio/video · Self-edited · Commentary & entertainment',
    ratio: '16:9',
    source: 'youtube',
    youtubeId: 'UCZ0v47MyDU',
    embedUrl: 'https://www.youtube.com/embed/UCZ0v47MyDU?autoplay=1&rel=0',
    directUrl: 'https://www.youtube.com/watch?v=UCZ0v47MyDU',
    thumbnail: 'https://img.youtube.com/vi/UCZ0v47MyDU/maxresdefault.jpg',
    fallbackThumbnail: 'https://img.youtube.com/vi/UCZ0v47MyDU/hqdefault.jpg',
    duration: '11:45',
    cutsEstimate: '85+ cuts · Engaging pacing',
    targetPlatform: 'YouTube Channel (16:9 Widescreen)',
    description: 'Another full self-shot, self-edited upload — pacing, transitions, sound effects, and dialogue clarity polished from start to delivery.',
    editHighlights: [
      'Carefully cut down 35 minutes of raw footage to an 11-minute crisp cut',
      'Graphic callouts highlighting key humor and insights',
      'Precise background music transitions marking tonal shifts',
      'Custom YouTube thumbnail graphic design'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'Photoshop', 'Audacity'],
    keyTechniques: {
      hook: 'High-energy audio intro with comedic sound punch',
      pacing: 'Tight editing eliminating hesitations and duplicate takes',
      audio: 'Consistent dialog levels with subtle room ambience',
      visuals: 'Split-screen reaction framing and smooth focal zooms'
    }
  },
  {
    id: 'proj-05',
    projectNumber: 'PROJECT 05',
    title: 'Programming Guruji — Core Walkthrough',
    subtitle: 'Instructional Code & Screen Recording Polish',
    trackId: 'V3',
    trackName: 'Programming Guruji — Long-form',
    trackColor: '#C97B63',
    trackDescription: 'Self audio/video · Self-edited · Tech education & tutorials',
    ratio: '16:9',
    source: 'youtube',
    youtubeId: 'fYggd8tJ7bg',
    embedUrl: 'https://www.youtube.com/embed/fYggd8tJ7bg?autoplay=1&rel=0',
    directUrl: 'https://www.youtube.com/watch?v=fYggd8tJ7bg',
    thumbnail: 'https://img.youtube.com/vi/fYggd8tJ7bg/maxresdefault.jpg',
    fallbackThumbnail: 'https://img.youtube.com/vi/fYggd8tJ7bg/hqdefault.jpg',
    duration: '18:10',
    cutsEstimate: '95+ cuts · Pedagogical pacing',
    targetPlatform: 'YouTube Channel (16:9 Widescreen)',
    description: 'Instructional video edited for supreme clarity — dead air trimmed, cursor movements smoothed, and screen code zoomed with high-contrast highlight boxes.',
    editHighlights: [
      '38% dead air eliminated for maximum learner retention',
      'Smooth pan & zoom onto relevant lines of code and UI menus',
      'Key concept callouts and diagrammatic overlays',
      'Clean vocal delivery with background noise reduction'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'Filmora', 'Audacity', 'Photoshop'],
    keyTechniques: {
      hook: 'Immediate statement of what the learner will build by video end',
      pacing: 'Synchronized typing & speech cadence without dragging',
      audio: 'Crisp studio vocal clarity eliminating keyboard clicking noise',
      visuals: 'Syntax-friendly zoom insets with crisp 1080p rendering'
    }
  },
  {
    id: 'proj-06',
    projectNumber: 'PROJECT 06',
    title: 'Programming Guruji — Software Lesson',
    subtitle: 'Full Production, Filming & Graphics Sync',
    trackId: 'V3',
    trackName: 'Programming Guruji — Long-form',
    trackColor: '#C97B63',
    trackDescription: 'Self audio/video · Self-edited · Tech education & tutorials',
    ratio: '16:9',
    source: 'youtube',
    youtubeId: 'Fv1hxtRiw2U',
    embedUrl: 'https://www.youtube.com/embed/Fv1hxtRiw2U?autoplay=1&rel=0',
    directUrl: 'https://www.youtube.com/watch?v=Fv1hxtRiw2U',
    thumbnail: 'https://img.youtube.com/vi/Fv1hxtRiw2U/maxresdefault.jpg',
    fallbackThumbnail: 'https://img.youtube.com/vi/Fv1hxtRiw2U/hqdefault.jpg',
    duration: '15:30',
    cutsEstimate: '80+ cuts · Structured curriculum',
    targetPlatform: 'YouTube Channel (16:9 Widescreen)',
    description: 'End-to-end filming, voiceover synchronization, and graphics for a step-by-step software walkthrough built to train students effectively.',
    editHighlights: [
      'A-roll talking head integrated cleanly with software screencasts',
      'Structured chapter markers mapping curriculum progression',
      'Consistent branded intros, lower thirds, and callout arrows',
      'Audio leveling matching professional e-learning standards'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'Filmora', 'Audacity'],
    keyTechniques: {
      hook: 'Before & after outcome demonstration in first 15 seconds',
      pacing: 'Step-by-step sequential breakdown respecting cognitive load',
      audio: 'De-essed vocal track with warmth and clean presence',
      visuals: 'Spotlight dimming of irrelevant UI during key explanations'
    }
  },
  {
    id: 'proj-07',
    projectNumber: 'PROJECT 07',
    title: 'Programming Guruji — Hands-On Class',
    subtitle: 'Structured Lesson & Consistent Branding',
    trackId: 'V3',
    trackName: 'Programming Guruji — Long-form',
    trackColor: '#C97B63',
    trackDescription: 'Self audio/video · Self-edited · Tech education & tutorials',
    ratio: '16:9',
    source: 'youtube',
    youtubeId: 'o-8KDVPbVgA',
    embedUrl: 'https://www.youtube.com/embed/o-8KDVPbVgA?autoplay=1&rel=0',
    directUrl: 'https://www.youtube.com/watch?v=o-8KDVPbVgA',
    thumbnail: 'https://img.youtube.com/vi/o-8KDVPbVgA/maxresdefault.jpg',
    fallbackThumbnail: 'https://img.youtube.com/vi/o-8KDVPbVgA/hqdefault.jpg',
    duration: '16:45',
    cutsEstimate: '90+ cuts · Clean education cut',
    targetPlatform: 'YouTube Channel (16:9 Widescreen)',
    description: 'Edited from raw screen and camera footage into a clean, structured lesson with consistent branding and interactive learning pauses.',
    editHighlights: [
      'Visual highlights on keyboard shortcuts and commands',
      'Clean audio mix removing breath sounds and microphone pops',
      'Smooth cutaways between code execution and conceptual slides',
      'Endscreen cards configured for playlist retention'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'Photoshop', 'Audacity'],
    keyTechniques: {
      hook: 'Clear visual demonstration of the final working code project',
      pacing: 'Calculated pause beats after complex instructions',
      audio: 'Warm vocal tone master with noise suppression',
      visuals: 'High-contrast typography for code snippets and hotkeys'
    }
  },
  {
    id: 'proj-08',
    projectNumber: 'PROJECT 08',
    title: 'Programming Guruji — Deep-Dive Masterclass',
    subtitle: 'End-to-End Producer, Narrator & Editor',
    trackId: 'V3',
    trackName: 'Programming Guruji — Long-form',
    trackColor: '#C97B63',
    trackDescription: 'Self audio/video · Self-edited · Tech education & tutorials',
    ratio: '16:9',
    source: 'youtube',
    youtubeId: 'p_gEsFw3Ckc',
    embedUrl: 'https://www.youtube.com/embed/p_gEsFw3Ckc?autoplay=1&rel=0',
    directUrl: 'https://www.youtube.com/watch?v=p_gEsFw3Ckc',
    thumbnail: 'https://img.youtube.com/vi/p_gEsFw3Ckc/maxresdefault.jpg',
    fallbackThumbnail: 'https://img.youtube.com/vi/p_gEsFw3Ckc/hqdefault.jpg',
    duration: '22:15',
    cutsEstimate: '130+ cuts · In-depth masterclass',
    targetPlatform: 'YouTube Channel (16:9 Widescreen)',
    description: 'Another full self-produced episode — shot, narrated, and edited end-to-end. Keeps viewers engaged throughout a 20+ minute technical class.',
    editHighlights: [
      'Pacing curves designed specifically to sustain watch time over 20+ minutes',
      'Diagrammatic motion overlays explaining underlying concepts',
      'Multi-section audio transitions marking module completions',
      'High-CTR thumbnail creation in Photoshop'
    ],
    toolsUsed: ['Adobe Premiere Pro', 'Filmora', 'Audacity', 'Photoshop'],
    keyTechniques: {
      hook: 'Roadmap preview outlining the 4 crucial milestones ahead',
      pacing: 'Dynamic re-hooks at minute 5, 10, and 15 to combat drop-off',
      audio: 'Broadcast-quality voice mastering with multi-band compression',
      visuals: 'Clean animated progress indicators keeping learners oriented'
    }
  }
];

export const WORKFLOW_STEPS = [
  {
    step: '01',
    name: 'Ingest & Multi-Track Assembly',
    duration: 'Phase 1',
    description: 'Ingest raw camera files, screencasts, and microphone audio. Perform dual-system audio synchronization, eliminate false starts, duplicate takes, and silence dead air.'
  },
  {
    step: '02',
    name: 'Rhythm, Hook & Narrative Pacing',
    duration: 'Phase 2',
    description: 'Craft the critical first 3 seconds hook. Establish rhythm with J-cuts, L-cuts, and micro punch zooms. For tutorials, balance information density against viewer cognitive load.'
  },
  {
    step: '03',
    name: 'Kinetic Graphics & Motion Titling',
    duration: 'Phase 3',
    description: 'Add dynamic single-word subtitles, code highlight boxes, callout arrows, lower thirds, and branded motion assets to visually reinforce auditory teaching points.'
  },
  {
    step: '04',
    name: 'Sound Design & Dialogue Mastering',
    duration: 'Phase 4',
    description: 'Vocal noise removal, parametric EQ, de-essing, multi-band compression, and audio ducking (-18dB under speech). Master overall loudness to YouTube/social standard (-14 LUFS).'
  },
  {
    step: '05',
    name: 'Color Grading & Multi-Format Delivery',
    duration: 'Phase 5',
    description: 'Rec.709 color balance, skin-tone curve adjustment, and contrast enhancement. Multi-format exports: vertical 1080x1920 (9:16) and widescreen 1920x1080 (16:9) high-bitrate masters.'
  }
];

export const SOFTWARE_TOOLKIT = [
  {
    name: 'Adobe Premiere Pro',
    category: 'Desktop NLE',
    level: 'Primary Tool',
    details: 'Multi-cam sync, complex nested timelines, dynamic link with Adobe suite, Lumetri color grading.'
  },
  {
    name: 'CapCut Pro',
    category: 'Short-Form & Mobile',
    level: 'Advanced',
    details: 'Kinetic subtitle generation, speed ramps, trending sound alignment, 9:16 vertical formatting.'
  },
  {
    name: 'VN Video Editor',
    category: 'Mobile & Rapid Cuts',
    level: 'Advanced',
    details: 'Keyframe curve control, clean mobile trimming, PIP overlays, on-the-go social exports.'
  },
  {
    name: 'Wondershare Filmora',
    category: 'Desktop NLE',
    level: 'Expert',
    details: 'Fast turnarounds, screen recording assembly, preset motion callouts, rapid tutorial cutting.'
  },
  {
    name: 'Audacity',
    category: 'Audio Engineering',
    level: 'Advanced',
    details: 'Noise profile reduction, equalization, compression, vocal warmth, audio pop/click removal.'
  },
  {
    name: 'Adobe Photoshop',
    category: 'Design & Graphics',
    level: 'Advanced',
    details: 'High-CTR YouTube thumbnail design, graphic assets, transparency cutouts, channel banners.'
  },
  {
    name: 'Adobe Illustrator & InDesign',
    category: 'Vector & Layout',
    level: 'Proficient',
    details: 'Vector icons, brand typography marks, channel identity guides, multi-page curriculum visuals.'
  },
  {
    name: 'AI Productivity Tools',
    category: 'Workflow Acceleration',
    level: 'Integrated',
    details: 'Speech enhancement, auto-transcription verification, B-roll sourcing, script structure assistance.'
  }
];
