import React, { useState } from 'react';
import { Menu, X, Sun, Moon, Sparkles, Film } from 'lucide-react';

interface NavbarProps {
  onBookClick: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  onBookClick, 
  theme, 
  onToggleTheme 
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FFFFFF]/90 dark:bg-[#090A0D]/90 backdrop-blur-md border-b border-slate-200 dark:border-[#222631] transition-colors">
      <div className="max-w-[1340px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6 h-18">
          {/* Zone 1: Brand Wordmark (Streaming Platform Brand) */}
          <div className="flex items-center gap-3 shrink-0">
            <a 
              href="#hero" 
              onClick={(e) => { e.preventDefault(); scrollTo('hero'); }}
              className="flex items-center gap-2 group"
            >
              <div className="w-8 h-8 rounded-lg bg-[#D97706] dark:bg-[#E5A93C] text-white dark:text-black flex items-center justify-center font-bold text-sm shadow-md">
                MS
              </div>
              <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-slate-900 dark:text-[#ECEAE5] group-hover:text-[#D97706] dark:group-hover:text-[#E5A93C] transition-colors whitespace-nowrap font-display">
                MOHIT SINGH<span className="text-[#D97706] dark:text-[#E5A93C]">.</span>
              </span>
            </a>
            <span className="hidden xl:inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/10 text-amber-700 dark:bg-amber-400/10 dark:text-amber-400 border border-amber-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
              ON-DEMAND SUITE
            </span>
          </div>

          {/* Zone 2: 4-5 Clean Single-Line Streaming Nav Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600 dark:text-[#90949C]">
            <a 
              href="#hero" 
              onClick={(e) => { e.preventDefault(); scrollTo('hero'); }}
              className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors whitespace-nowrap"
            >
              Featured Billboard
            </a>
            <a 
              href="#recent" 
              onClick={(e) => { e.preventDefault(); scrollTo('recent'); }}
              className="text-[#D97706] dark:text-[#E5A93C] hover:opacity-80 transition-opacity whitespace-nowrap"
            >
              Drive Vault (8 Cuts)
            </a>
            <a 
              href="#work" 
              onClick={(e) => { e.preventDefault(); scrollTo('work'); }}
              className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors whitespace-nowrap"
            >
              Series &amp; Tutorials
            </a>
            <a 
              href="#timeline" 
              onClick={(e) => { e.preventDefault(); scrollTo('timeline'); }}
              className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors whitespace-nowrap"
            >
              NLE Bay
            </a>
            <a 
              href="#about" 
              onClick={(e) => { e.preventDefault(); scrollTo('about'); }}
              className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors whitespace-nowrap"
            >
              Director Info
            </a>
          </nav>

          {/* Zone 3: Theme Toggle & Primary Action */}
          <div className="flex items-center gap-2.5 shrink-0">
            {/* Theme Toggle Button */}
            <button
              onClick={onToggleTheme}
              className="flex items-center gap-2 px-3 py-2 text-xs font-bold rounded-lg border border-slate-200 dark:border-[#282D39] bg-slate-100 hover:bg-slate-200 dark:bg-[#14161C] dark:hover:bg-[#1D212B] text-slate-700 dark:text-[#ECEAE5] transition-colors shadow-sm"
              title={theme === 'dark' ? "Switch to Light Studio Mode" : "Switch to Deep Space Dark Mode"}
              aria-label="Toggle theme mode"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-4 h-4 text-[#E5A93C]" />
                  <span className="hidden sm:inline font-mono">Light Studio</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-indigo-600" />
                  <span className="hidden sm:inline font-mono">Deep Space</span>
                </>
              )}
            </button>

            {/* Primary Action Button */}
            <button
              onClick={onBookClick}
              className="hidden sm:inline-flex px-4 py-2 text-xs font-bold text-white dark:text-black bg-[#D97706] hover:bg-[#B45309] dark:bg-[#E5A93C] dark:hover:bg-[#F2B705] rounded-lg transition-all shadow-md whitespace-nowrap hover:scale-102"
            >
              Book an Edit
            </button>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-slate-600 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-white rounded-lg"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-slate-200 dark:border-[#222631] space-y-2 bg-white dark:bg-[#0E1015]">
            <a
              href="#hero"
              onClick={(e) => { e.preventDefault(); scrollTo('hero'); }}
              className="block px-3 py-2 text-sm font-semibold text-slate-700 dark:text-[#ECEAE5]"
            >
              Featured Billboard
            </a>
            <a
              href="#recent"
              onClick={(e) => { e.preventDefault(); scrollTo('recent'); }}
              className="block px-3 py-2 text-sm font-bold text-[#D97706] dark:text-[#E5A93C]"
            >
              Drive Vault (8 Cuts)
            </a>
            <a
              href="#work"
              onClick={(e) => { e.preventDefault(); scrollTo('work'); }}
              className="block px-3 py-2 text-sm font-semibold text-slate-700 dark:text-[#ECEAE5]"
            >
              Series &amp; Tutorials
            </a>
            <a
              href="#timeline"
              onClick={(e) => { e.preventDefault(); scrollTo('timeline'); }}
              className="block px-3 py-2 text-sm font-semibold text-slate-700 dark:text-[#ECEAE5]"
            >
              NLE Bay
            </a>
            <a
              href="#about"
              onClick={(e) => { e.preventDefault(); scrollTo('about'); }}
              className="block px-3 py-2 text-sm font-semibold text-slate-700 dark:text-[#ECEAE5]"
            >
              Director Info
            </a>
            <div className="pt-2 px-3 flex gap-2">
              <button
                onClick={onToggleTheme}
                className="flex-1 py-2 text-center text-xs font-bold border border-slate-300 dark:border-[#2A2E3B] rounded-lg text-slate-700 dark:text-white"
              >
                {theme === 'dark' ? '☀️ Light Studio' : '🌙 Deep Space'}
              </button>
              <button
                onClick={() => { setMobileMenuOpen(false); onBookClick(); }}
                className="flex-1 py-2 text-center text-xs font-bold text-white dark:text-black bg-[#D97706] dark:bg-[#E5A93C] rounded-lg"
              >
                Book an Edit
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
