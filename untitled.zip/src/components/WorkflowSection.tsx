import React from 'react';
import { Layers, Scissors, Sparkles, Volume2, MonitorCheck } from 'lucide-react';

const STEPS = [
  {
    step: '01',
    name: 'Assembly & Dual Sync',
    summary: 'Cutting false starts & dead air.',
    icon: <Layers className="w-6 h-6 text-[#E5A93C]" />
  },
  {
    step: '02',
    name: 'Hook & Pacing Rhythm',
    summary: '1.5-second hook & J/L cuts.',
    icon: <Scissors className="w-6 h-6 text-[#5FA8A0]" />
  },
  {
    step: '03',
    name: 'Kinetic Subtitles',
    summary: 'Word-by-word motion captions.',
    icon: <Sparkles className="w-6 h-6 text-[#C97B63]" />
  },
  {
    step: '04',
    name: 'Dialogue Mastering',
    summary: '-14 LUFS vocal normalization & ducking.',
    icon: <Volume2 className="w-6 h-6 text-[#9B8CD9]" />
  },
  {
    step: '05',
    name: 'Rec.709 Color Master',
    summary: 'OLED skin tone balancing & multi-export.',
    icon: <MonitorCheck className="w-6 h-6 text-emerald-400" />
  }
];

export const WorkflowSection: React.FC = () => {
  return (
    <section id="workflow" className="py-14 sm:py-20 border-b border-slate-200 dark:border-[#20242D] bg-slate-50 dark:bg-[#0E1014] transition-colors">
      <div className="max-w-[1300px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-200 dark:border-[#20242D]">
          <div>
            <div className="text-xs sm:text-sm font-mono text-[#D97706] dark:text-[#E5A93C] uppercase tracking-wider mb-2 font-bold">
              PIPELINE · 5 POST-PRODUCTION PHASES
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-[#ECEAE5] font-display">
              Raw Takes to Final Master.
            </h2>
          </div>
        </div>

        {/* 5 Big Bold Phase Cards */}
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {STEPS.map((step) => (
            <div
              key={step.step}
              className="bg-white dark:bg-[#14161C] border-2 border-slate-200 dark:border-[#232731] hover:border-[#D97706] dark:hover:border-[#E5A93C] rounded-2xl p-5 flex flex-col justify-between transition-all group shadow-sm hover:shadow-md"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl sm:text-3xl font-extrabold font-display text-[#D97706] dark:text-[#E5A93C]">
                    {step.step}
                  </span>
                  <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-[#1B1E26] border border-slate-200 dark:border-[#282C36] group-hover:scale-110 transition-transform">
                    {step.icon}
                  </div>
                </div>

                <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-[#ECEAE5] font-display mb-2 leading-snug">
                  {step.name}
                </h3>

                <p className="text-sm sm:text-base text-slate-700 dark:text-[#B0B4BC] font-medium leading-relaxed">
                  {step.summary}
                </p>
              </div>

              <div className="mt-6 pt-3 border-t border-slate-200 dark:border-[#20242D] text-xs font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                PHASE VERIFIED ✓
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
