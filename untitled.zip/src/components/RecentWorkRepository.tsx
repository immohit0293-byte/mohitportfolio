import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause,
  ChevronLeft, 
  ChevronRight, 
  Maximize2, 
  ExternalLink, 
  RotateCcw, 
  Film, 
  Sparkles, 
  Copy, 
  Check, 
  ListFilter, 
  MonitorPlay,
  TrendingUp,
  Flame
} from 'lucide-react';
import { VideoProject, DRIVE_FOLDER_VIDEOS } from '../data/projects';

interface RecentWorkRepositoryProps {
  onOpenTheatre: (project: VideoProject) => void;
}

export const RecentWorkRepository: React.FC<RecentWorkRepositoryProps> = ({ onOpenTheatre }) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [viewMode, setViewMode] = useState<'spotlight' | 'all-list'>('spotlight');
  const [iframeKey, setIframeKey] = useState<number>(0);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isAutoCycle, setIsAutoCycle] = useState<boolean>(false);

  const currentProject = DRIVE_FOLDER_VIDEOS[currentIndex];

  useEffect(() => {
    if (!isAutoCycle || viewMode !== 'spotlight') return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % DRIVE_FOLDER_VIDEOS.length);
      setIframeKey((k) => k + 1);
    }, 2500);
    return () => clearInterval(interval);
  }, [isAutoCycle, viewMode]);

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % DRIVE_FOLDER_VIDEOS.length);
    setIframeKey((k) => k + 1);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + DRIVE_FOLDER_VIDEOS.length) % DRIVE_FOLDER_VIDEOS.length);
    setIframeKey((k) => k + 1);
  };

  const handleSelect = (idx: number) => {
    setCurrentIndex(idx);
    setIframeKey((k) => k + 1);
  };

  const handleCopy = (proj: VideoProject) => {
    navigator.clipboard.writeText(proj.directUrl);
    setCopiedId(proj.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const embedUrl = `https://drive.google.com/file/d/${currentProject.driveId}/preview`;

  return (
    <section id="recent" className="py-12 sm:py-16 border-b border-slate-200 dark:border-[#222631] bg-slate-50 dark:bg-[#0E1015] transition-colors">
      <div className="max-w-[1340px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-slate-200 dark:border-[#20242D]">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#D97706] dark:text-[#E5A93C] uppercase tracking-wider mb-2">
              <Flame className="w-4 h-4 text-[#D97706] dark:text-[#E5A93C]" />
              <span>TRENDING REEL SHELF · DRIVE VAULT ({DRIVE_FOLDER_VIDEOS.length} CUTS)</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-[#ECEAE5] font-display">
              Social Media Manager Vault.
            </h2>
            <p className="text-base sm:text-xl text-slate-700 dark:text-[#B0B4BC] mt-1.5 font-medium max-w-xl">
              1.5s hooks, dynamic captioning &amp; sound-off mobile retention.
            </p>
          </div>

          {/* Controls: Deck vs Feed View */}
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={() => setIsAutoCycle(!isAutoCycle)}
              className={`px-3 py-2 text-xs font-mono font-bold rounded-lg border transition-colors flex items-center gap-1.5 ${
                isAutoCycle 
                  ? 'bg-[#D97706] text-white dark:bg-[#E5A93C] dark:text-black border-transparent shadow-sm' 
                  : 'bg-white dark:bg-[#181B22] text-slate-600 dark:text-[#90949C] border-slate-200 dark:border-[#252935] hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {isAutoCycle ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              <span>{isAutoCycle ? 'Auto-Cycle ON' : 'Auto-Cycle'}</span>
            </button>

            <div className="flex items-center p-1 bg-white dark:bg-[#14161C] border border-slate-200 dark:border-[#232731] rounded-lg shadow-sm">
              <button
                onClick={() => setViewMode('spotlight')}
                className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-md transition-colors ${
                  viewMode === 'spotlight'
                    ? 'bg-[#D97706] dark:bg-[#E5A93C] text-white dark:text-black shadow-sm'
                    : 'text-slate-600 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-[#ECEAE5]'
                }`}
              >
                <MonitorPlay className="w-4 h-4" />
                <span>One-by-One</span>
              </button>
              <button
                onClick={() => setViewMode('all-list')}
                className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-md transition-colors ${
                  viewMode === 'all-list'
                    ? 'bg-[#D97706] dark:bg-[#E5A93C] text-white dark:text-black shadow-sm'
                    : 'text-slate-600 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-[#ECEAE5]'
                }`}
              >
                <ListFilter className="w-4 h-4" />
                <span>All 8 Cuts</span>
              </button>
            </div>
          </div>
        </div>

        {/* ONE-BY-ONE SPOTLIGHT STAGE */}
        {viewMode === 'spotlight' && (
          <div className="mt-8 space-y-6">
            {/* Stepper Header */}
            <div className="flex flex-wrap items-center justify-between gap-4 bg-white dark:bg-[#14161C] border border-slate-200 dark:border-[#232731] rounded-xl p-3 sm:p-4 shadow-sm">
              <div className="flex items-center gap-3">
                <button
                  onClick={handlePrev}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-800 dark:text-[#ECEAE5] bg-slate-100 dark:bg-[#1E222B] hover:bg-slate-200 dark:hover:bg-[#282D39] border border-slate-200 dark:border-[#2D3341] rounded-lg transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Prev</span>
                </button>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded text-white dark:text-black" style={{ backgroundColor: currentProject.trackColor }}>
                    {currentProject.fileName || currentProject.projectNumber}
                  </span>
                  <span className="text-base sm:text-lg font-bold text-slate-900 dark:text-[#ECEAE5] truncate max-w-xs sm:max-w-md">
                    {currentProject.title}
                  </span>
                </div>
              </div>

              {/* Number Buttons */}
              <div className="flex items-center gap-1.5">
                {DRIVE_FOLDER_VIDEOS.map((proj, idx) => (
                  <button
                    key={proj.id}
                    onClick={() => handleSelect(idx)}
                    className={`w-8 h-8 text-xs font-mono font-bold rounded-lg flex items-center justify-center transition-all ${
                      idx === currentIndex
                        ? 'bg-[#D97706] dark:bg-[#E5A93C] text-white dark:text-black shadow-md scale-105'
                        : 'bg-slate-100 dark:bg-[#181B22] text-slate-600 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-[#252934]'
                    }`}
                  >
                    {idx + 1}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIframeKey((k) => k + 1)}
                  className="p-2 text-slate-600 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-[#1A1D24] rounded-lg"
                  title="Reload stream"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>

                <button
                  onClick={handleNext}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white dark:text-black bg-[#D97706] hover:bg-[#B45309] dark:bg-[#E5A93C] dark:hover:bg-[#F2B705] rounded-lg transition-colors shadow-sm"
                >
                  <span>Next Cut</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* In-Place Smartphone 9:16 Stage */}
            <div className="bg-white dark:bg-[#12141A] border-2 border-slate-200 dark:border-[#232731] rounded-2xl overflow-hidden shadow-xl grid grid-cols-1 lg:grid-cols-12 transition-colors">
              {/* Smartphone Viewport */}
              <div className="lg:col-span-6 bg-slate-950 dark:bg-[#08090C] p-4 sm:p-6 flex flex-col items-center justify-center border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-[#20242D]">
                <div className="relative w-full max-w-[340px] aspect-[9/16] h-[68vh] max-h-[580px] rounded-2xl overflow-hidden bg-black border-2 border-slate-700 dark:border-[#2A2E3B] shadow-2xl flex items-center justify-center">
                  <iframe
                    key={`${currentProject.id}-${iframeKey}`}
                    src={embedUrl}
                    title={currentProject.title}
                    className="w-full h-full border-0 absolute inset-0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
                    allowFullScreen
                    referrerPolicy="strict-origin-when-cross-origin"
                  />
                  <div className="absolute top-3 right-3 z-10">
                    <a
                      href={currentProject.directUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1 text-xs font-bold bg-slate-900/90 text-white hover:text-amber-400 border border-slate-700 rounded backdrop-blur-sm transition-colors flex items-center gap-1"
                    >
                      <span>Drive Tab</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>

                <div className="w-full max-w-[340px] mt-3 flex items-center justify-between text-xs text-slate-400 dark:text-[#90949C]">
                  <span className="font-mono font-bold text-white">{currentProject.fileName}</span>
                  <button
                    onClick={() => handleCopy(currentProject)}
                    className="hover:text-white flex items-center gap-1 font-mono"
                  >
                    {copiedId === currentProject.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedId === currentProject.id ? 'Copied' : 'Share'}</span>
                  </button>
                </div>
              </div>

              {/* Strategy & Cuts Anatomy (Big Bold Cards) */}
              <div className="lg:col-span-6 p-6 sm:p-8 bg-white dark:bg-[#14161C] flex flex-col justify-between space-y-6">
                <div className="space-y-4">
                  <div>
                    <span className="text-xs font-mono font-bold text-[#D97706] dark:text-[#E5A93C] uppercase tracking-wider block mb-1">
                      {currentProject.targetPlatform} · {currentProject.duration}
                    </span>
                    <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-[#ECEAE5] font-display leading-tight">
                      {currentProject.title}
                    </h3>
                  </div>

                  {/* High-Impact Stat Blocks */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-slate-50 dark:bg-[#181B22] p-3.5 rounded-xl border border-slate-200 dark:border-[#252935]">
                      <span className="text-xs font-mono text-slate-500 dark:text-[#90949C] block uppercase font-bold">Goal</span>
                      <span className="text-base sm:text-lg font-bold text-slate-900 dark:text-[#ECEAE5]">
                        {currentProject.socialManagerStrategy?.objective || 'High Retention'}
                      </span>
                    </div>
                    <div className="bg-slate-50 dark:bg-[#181B22] p-3.5 rounded-xl border border-slate-200 dark:border-[#252935]">
                      <span className="text-xs font-mono text-slate-500 dark:text-[#90949C] block uppercase font-bold">Pacing</span>
                      <span className="text-base sm:text-lg font-bold text-[#D97706] dark:text-[#E5A93C]">
                        {currentProject.cutsEstimate}
                      </span>
                    </div>
                  </div>

                  {/* Highlights */}
                  <div className="space-y-2 border-t border-slate-200 dark:border-[#232731] pt-3">
                    {currentProject.editHighlights.map((hl, i) => (
                      <div key={i} className="flex items-start gap-2.5 text-sm sm:text-base text-slate-700 dark:text-[#D0D4DC] font-medium">
                        <span className="text-[#D97706] dark:text-[#E5A93C] font-bold mt-0.5">▶</span>
                        <span>{hl}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Big Actions */}
                <div className="pt-4 border-t border-slate-200 dark:border-[#232731] flex gap-3">
                  <button
                    onClick={() => onOpenTheatre(currentProject)}
                    className="flex-1 py-3 px-4 text-sm font-bold text-white dark:text-black bg-[#D97706] hover:bg-[#B45309] dark:bg-[#E5A93C] dark:hover:bg-[#F2B705] rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
                  >
                    <Maximize2 className="w-4 h-4" />
                    <span>Expand Full Cinema Theatre</span>
                  </button>
                  <a
                    href={currentProject.directUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-3 px-4 text-sm font-bold text-slate-700 dark:text-[#ECEAE5] bg-slate-100 hover:bg-slate-200 dark:bg-[#1E222B] dark:hover:bg-[#282D39] border border-slate-200 dark:border-[#2D3341] rounded-xl transition-colors flex items-center gap-1.5"
                  >
                    <ExternalLink className="w-4 h-4 text-slate-500 dark:text-[#90949C]" />
                  </a>
                </div>
              </div>
            </div>

            {/* Reel Carousel */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 pt-2">
              {DRIVE_FOLDER_VIDEOS.map((proj, idx) => {
                const isActive = idx === currentIndex;
                return (
                  <button
                    key={proj.id}
                    onClick={() => handleSelect(idx)}
                    className={`relative rounded-xl overflow-hidden border text-left transition-all p-1.5 shadow-sm ${
                      isActive
                        ? 'border-[#D97706] dark:border-[#E5A93C] bg-amber-50 dark:bg-[#202530] ring-2 ring-[#D97706]/40 dark:ring-[#E5A93C]/50'
                        : 'border-slate-200 dark:border-[#232731] bg-white dark:bg-[#14161C] hover:border-slate-400 dark:hover:border-[#3E4350]'
                    }`}
                  >
                    <div className="relative aspect-[9/16] max-h-[140px] bg-black rounded-lg overflow-hidden flex items-center justify-center">
                      <img
                        src={proj.thumbnail}
                        alt={proj.title}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      {isActive && (
                        <div className="absolute inset-0 bg-amber-500/25 flex items-center justify-center">
                          <Play className="w-6 h-6 fill-current text-white" />
                        </div>
                      )}
                    </div>
                    <span className="text-xs font-mono font-bold block text-slate-900 dark:text-[#ECEAE5] truncate mt-1">
                      {proj.fileName}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* FEED MODE */}
        {viewMode === 'all-list' && (
          <div className="mt-8 space-y-10">
            {DRIVE_FOLDER_VIDEOS.map((proj) => (
              <div
                key={proj.id}
                className="bg-white dark:bg-[#12141A] border-2 border-slate-200 dark:border-[#232731] rounded-2xl overflow-hidden shadow-md grid grid-cols-1 lg:grid-cols-12"
              >
                <div className="lg:col-span-5 bg-slate-950 dark:bg-[#08090C] p-5 flex items-center justify-center border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-[#20242D]">
                  <div className="relative w-full max-w-[280px] aspect-[9/16] h-[480px] rounded-xl overflow-hidden bg-black border border-slate-800">
                    <iframe
                      src={`https://drive.google.com/file/d/${proj.driveId}/preview`}
                      title={proj.title}
                      className="w-full h-full border-0 absolute inset-0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                      allowFullScreen
                      loading="lazy"
                    />
                  </div>
                </div>

                <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded text-white dark:text-black" style={{ backgroundColor: proj.trackColor }}>
                        {proj.fileName}
                      </span>
                      <span className="text-xs font-mono text-slate-500 dark:text-[#90949C]">{proj.duration}</span>
                    </div>

                    <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-[#ECEAE5] font-display">
                      {proj.title}
                    </h3>

                    <div className="space-y-1.5 border-t border-slate-200 dark:border-[#232731] pt-3">
                      {proj.editHighlights.map((hl, i) => (
                        <div key={i} className="flex items-start gap-2 text-sm sm:text-base text-slate-700 dark:text-[#D0D4DC] font-medium">
                          <span className="text-[#D97706] dark:text-[#E5A93C] font-bold">▶</span>
                          <span>{hl}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 pt-3 border-t border-slate-200 dark:border-[#232731]">
                    <button
                      onClick={() => onOpenTheatre(proj)}
                      className="px-5 py-2.5 rounded-lg bg-[#D97706] dark:bg-[#E5A93C] text-white dark:text-black font-bold text-sm hover:opacity-90"
                    >
                      Screen in Cinema
                    </button>
                    <a
                      href={proj.directUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-mono text-slate-500 dark:text-[#90949C] hover:underline"
                    >
                      Drive Direct ↗
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
