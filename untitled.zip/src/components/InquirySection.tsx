import React, { useState } from 'react';
import { Mail, Phone, ExternalLink, Send, Copy, Check } from 'lucide-react';

export const InquirySection: React.FC = () => {
  const [projectFormat, setProjectFormat] = useState<string>('Shorts & Reels (9:16)');
  const [turnaround, setTurnaround] = useState<string>('Standard (3–5 days)');
  const [clientName, setClientName] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  const emailRecipient = 'im.mohit0293@gmail.com';
  const emailPhone = '+91 7428181376';

  const generatedSubject = `Video Editing & Social Inquiry — ${projectFormat}`;
  const generatedBody = `Hi Mohit,

I would like to inquire about video editing / social media management services.

Format: ${projectFormat}
Turnaround: ${turnaround}
${clientName ? `Name / Channel: ${clientName}\n` : ''}
Let's connect to discuss raw footage and timeline.

Best,
${clientName || 'Creator / Client'}`;

  const mailtoLink = `mailto:${emailRecipient}?subject=${encodeURIComponent(generatedSubject)}&body=${encodeURIComponent(generatedBody)}`;

  const handleCopyDraft = () => {
    navigator.clipboard.writeText(`Subject: ${generatedSubject}\n\n${generatedBody}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="contact" className="py-14 sm:py-20 border-b border-slate-200 dark:border-[#20242D] bg-slate-50 dark:bg-[#08090B] transition-colors">
      <div className="max-w-[1300px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-200 dark:border-[#20242D]">
          <div>
            <div className="text-xs sm:text-sm font-mono text-[#D97706] dark:text-[#E5A93C] uppercase tracking-wider mb-2 font-bold">
              LET'S COLLABORATE · INQUIRIES &amp; BOOKING
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-[#ECEAE5] font-display">
              Book an Edit.
            </h2>
          </div>
        </div>

        <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Quick Configurator (Big Buttons, Less Text) */}
          <div className="lg:col-span-7 bg-white dark:bg-[#12141A] border-2 border-slate-200 dark:border-[#232731] rounded-2xl p-6 sm:p-8 space-y-5 shadow-sm">
            <div>
              <label className="text-xs font-mono font-bold text-slate-600 dark:text-[#90949C] block uppercase tracking-wider mb-2">
                1. SELECT VIDEO FORMAT
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                {[
                  'Shorts & Reels (9:16)',
                  'YouTube Long-Form (16:9)',
                  'Social Ad Creative',
                  'Channel Retainer'
                ].map((fmt) => (
                  <button
                    key={fmt}
                    type="button"
                    onClick={() => setProjectFormat(fmt)}
                    className={`py-3 px-3 text-xs sm:text-sm font-bold rounded-xl border transition-all text-left shadow-xs ${
                      projectFormat === fmt
                        ? 'bg-[#D97706] text-white dark:bg-[#E5A93C] dark:text-[#0B0C0E] border-[#D97706] dark:border-[#E5A93C]'
                        : 'bg-slate-50 dark:bg-[#181B22] border-slate-200 dark:border-[#252935] text-slate-800 dark:text-[#ECEAE5] hover:border-slate-400 dark:hover:border-[#3E4350]'
                    }`}
                  >
                    {fmt}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-mono font-bold text-slate-600 dark:text-[#90949C] block uppercase tracking-wider mb-2">
                2. TURNAROUND SPEED
              </label>
              <div className="grid grid-cols-3 gap-2">
                {['Standard (3–5 days)', 'Rush (24–48h)', 'Weekly Retainer'].map((spd) => (
                  <button
                    key={spd}
                    type="button"
                    onClick={() => setTurnaround(spd)}
                    className={`py-2.5 px-2 text-xs font-bold rounded-lg border transition-all text-center shadow-xs ${
                      turnaround === spd
                        ? 'bg-[#0D9488] text-white dark:bg-[#5FA8A0] dark:text-[#0B0C0E] border-[#0D9488] dark:border-[#5FA8A0]'
                        : 'bg-slate-50 dark:bg-[#181B22] border-slate-200 dark:border-[#252935] text-slate-800 dark:text-[#ECEAE5] hover:border-slate-400 dark:hover:border-[#3E4350]'
                    }`}
                  >
                    {spd}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-mono font-bold text-slate-600 dark:text-[#90949C] block uppercase tracking-wider mb-1.5">
                3. YOUR NAME OR CHANNEL
              </label>
              <input
                type="text"
                placeholder="e.g. Alex / Media Brand"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="w-full px-4 py-3 text-sm bg-slate-50 dark:bg-[#181B22] border border-slate-200 dark:border-[#252935] rounded-xl text-slate-900 dark:text-[#ECEAE5] placeholder-slate-400 dark:placeholder-[#5F636C] focus:outline-none focus:border-[#D97706] dark:focus:border-[#E5A93C] font-medium"
              />
            </div>

            <div className="pt-2 flex flex-wrap gap-3">
              <a
                href={mailtoLink}
                className="flex-1 py-3.5 px-5 text-sm font-bold text-white dark:text-[#0B0C0E] bg-[#D97706] hover:bg-[#B45309] dark:bg-[#E5A93C] dark:hover:bg-[#F2B705] rounded-xl transition-transform hover:scale-102 flex items-center justify-center gap-2 shadow-lg"
              >
                <Send className="w-4 h-4" />
                <span>Launch Email Draft</span>
              </a>

              <button
                type="button"
                onClick={handleCopyDraft}
                className="py-3.5 px-5 text-xs font-bold text-slate-800 dark:text-[#ECEAE5] bg-slate-100 hover:bg-slate-200 dark:bg-[#1E222B] dark:hover:bg-[#282D39] border border-slate-200 dark:border-[#2C313E] rounded-xl transition-colors flex items-center gap-1.5"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Copied' : 'Copy Brief'}</span>
              </button>
            </div>
          </div>

          {/* Direct Big Contacts */}
          <div className="lg:col-span-5 bg-white dark:bg-[#12141A] border-2 border-slate-200 dark:border-[#232731] rounded-2xl p-6 sm:p-8 flex flex-col justify-between space-y-6 shadow-sm">
            <div className="space-y-5">
              <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-[#ECEAE5] font-display">
                Direct Contact.
              </h3>

              <div className="space-y-4 pt-1">
                <div>
                  <span className="text-xs font-mono font-bold text-[#D97706] dark:text-[#E5A93C] uppercase block mb-0.5">
                    Email
                  </span>
                  <a
                    href={`mailto:${emailRecipient}`}
                    className="text-lg sm:text-xl font-bold text-slate-900 dark:text-[#ECEAE5] hover:text-[#D97706] dark:hover:text-[#E5A93C] transition-colors break-all"
                  >
                    {emailRecipient}
                  </a>
                </div>

                <div>
                  <span className="text-xs font-mono font-bold text-[#0D9488] dark:text-[#5FA8A0] uppercase block mb-0.5">
                    Phone / WhatsApp
                  </span>
                  <a
                    href="tel:+917428181376"
                    className="text-lg sm:text-xl font-bold text-slate-900 dark:text-[#ECEAE5] hover:text-[#0D9488] dark:hover:text-[#5FA8A0] transition-colors"
                  >
                    {emailPhone}
                  </a>
                </div>

                <div>
                  <span className="text-xs font-mono font-bold text-[#C97B63] uppercase block mb-0.5">
                    Location
                  </span>
                  <span className="text-base sm:text-lg font-bold text-slate-800 dark:text-[#ECEAE5]">
                    Noida, Uttar Pradesh, India (Remote Worldwide)
                  </span>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#08090C] border border-slate-200 dark:border-[#20242D] text-xs font-mono flex items-center justify-between text-slate-600 dark:text-[#90949C]">
              <span className="font-bold">STATUS: ACCEPTING CLIENTS</span>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
