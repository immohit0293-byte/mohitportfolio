import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX, 
  ZoomIn, 
  ZoomOut, 
  Layers, 
  SlidersHorizontal,
  Maximize,
  Sparkles,
  Info
} from 'lucide-react';
import { VideoProject, VIDEO_PROJECTS } from '../data/projects';

interface TimelineInspectorProps {
  onPlayProject: (project: VideoProject) => void;
  activeProject: VideoProject | null;
}

export const TimelineInspector: React.FC<TimelineInspectorProps> = ({
  onPlayProject,
  activeProject
}) => {
  const [playheadPercent, setPlayheadPercent] = useState<number>(24);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [hoveredClip, setHoveredClip] = useState<VideoProject | null>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  // Playhead scrubber animation loop
  useEffect(() => {
    let animId: number;
    if (isPlaying) {
      animId = window.requestAnimationFrame(function step() {
        setPlayheadPercent(prev => {
          if (prev >= 98) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 0.18;
        });
        if (isPlaying) {
          animId = window.requestAnimationFrame(step);
        }
      });
    }
    return () => window.cancelAnimationFrame(animId);
  }, [isPlaying]);

  // Compute timecode string based on percent (0 to 100% maps to 00:20:00:00)
  const totalFrames = Math.floor((playheadPercent / 100) * (20 * 60 * 30)); // 20 mins @ 30fps
  const hours = Math.floor(totalFrames / (3600 * 30));
  const minutes = Math.floor((totalFrames % (3600 * 30)) / (60 * 30));
  const seconds = Math.floor((totalFrames % (60 * 30)) / 30);
  const frames = totalFrames % 30;

  const formattedTimecode = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}:${String(frames).padStart(2, '0')}`;

  const handleTimelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percent = Math.max(0, Math.min(100, (clickX / rect.width) * 100));
    setPlayheadPercent(percent);
  };

  const handleDrag = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.buttons === 1) { // Left mouse button down
      handleTimelineClick(e);
    }
  };

  // Group projects into track lanes
  const v1Clips = VIDEO_PROJECTS.filter(p => p.trackId === 'V1' || p.trackId === 'DRIVE');
  const v2Clips = VIDEO_PROJECTS.filter(p => p.trackId === 'V2');
  const v3Clips = VIDEO_PROJECTS.filter(p => p.trackId === 'V3');

  return (
    <section id="timeline" className="py-16 sm:py-20 border-b border-slate-200 dark:border-[#20242D] bg-slate-50 dark:bg-[#0E1014] transition-colors">
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-[#D97706] dark:text-[#E5A93C] uppercase tracking-wider mb-2 font-bold">
              <span className="w-2 h-2 rounded-full bg-[#D97706] dark:bg-[#E5A93C]" />
              <span>Interactive NLE Sequence</span>
              <span className="text-slate-400 dark:text-[#5F636C]">·</span>
              <span className="text-slate-600 dark:text-[#90949C]">The Edit Bay</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-[#ECEAE5] font-display">
              NLE Timeline Sequence.
            </h2>
            <p className="text-base sm:text-xl text-slate-700 dark:text-[#B0B4BC] mt-2 font-medium max-w-xl">
              Scrub the live sequence ruler or click any clip block to screen its cut.
            </p>
          </div>

          {/* Timecode & Transport Bar */}
          <div className="flex flex-wrap items-center gap-3 bg-white dark:bg-[#151820] border border-slate-200 dark:border-[#232731] rounded-xl p-2.5 shadow-sm">
            <div className="flex items-center gap-2 px-3 py-1 bg-slate-100 dark:bg-[#090A0D] border border-slate-200 dark:border-[#20242D] rounded font-mono text-sm font-bold text-[#D97706] dark:text-[#E5A93C] tracking-widest tabular-nums">
              <span className="text-slate-400 dark:text-[#5F636C] text-xs">TC</span>
              <span>{formattedTimecode}</span>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setPlayheadPercent(0)}
                className="p-1.5 text-slate-600 hover:text-slate-900 dark:text-[#90949C] dark:hover:text-[#ECEAE5] hover:bg-slate-100 dark:hover:bg-[#20242D] rounded transition-colors"
                title="Jump to Sequence Start"
                aria-label="Jump to start"
              >
                <SkipBack className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className={`p-1.5 rounded transition-colors ${
                  isPlaying 
                    ? 'bg-[#D97706] text-white dark:bg-[#E5A93C] dark:text-[#0B0C0E]' 
                    : 'bg-slate-200 text-slate-800 dark:bg-[#232731] dark:text-[#ECEAE5] hover:bg-slate-300 dark:hover:bg-[#2C313E]'
                }`}
                title={isPlaying ? "Pause Scrubber" : "Play Scrubber"}
                aria-label={isPlaying ? "Pause timeline" : "Play timeline"}
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
              </button>
              <button
                onClick={() => setPlayheadPercent(98)}
                className="p-1.5 text-slate-600 hover:text-slate-900 dark:text-[#90949C] dark:hover:text-[#ECEAE5] hover:bg-slate-100 dark:hover:bg-[#20242D] rounded transition-colors"
                title="Jump to Sequence End"
                aria-label="Jump to end"
              >
                <SkipForward className="w-4 h-4" />
              </button>
            </div>

            <div className="hidden sm:flex items-center gap-1 border-l border-slate-200 dark:border-[#282C35] pl-2">
              <button
                onClick={() => setZoomLevel(Math.max(0.75, zoomLevel - 0.25))}
                className="p-1.5 text-slate-600 hover:text-slate-900 dark:text-[#90949C] dark:hover:text-[#ECEAE5] hover:bg-slate-100 dark:hover:bg-[#20242D] rounded transition-colors"
                title="Zoom Out"
                aria-label="Zoom out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-[11px] font-mono text-slate-600 dark:text-[#90949C] px-1 font-bold">
                {Math.round(zoomLevel * 100)}%
              </span>
              <button
                onClick={() => setZoomLevel(Math.min(1.5, zoomLevel + 0.25))}
                className="p-1.5 text-slate-600 hover:text-slate-900 dark:text-[#90949C] dark:hover:text-[#ECEAE5] hover:bg-slate-100 dark:hover:bg-[#20242D] rounded transition-colors"
                title="Zoom In"
                aria-label="Zoom in"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* NLE Timeline Console Frame */}
        <div className="bg-white dark:bg-[#12141A] border border-slate-200 dark:border-[#232731] rounded-xl overflow-hidden shadow-xl transition-colors">
          {/* Timeline Timecode Ruler */}
          <div className="relative h-9 border-b border-slate-200 dark:border-[#232731] bg-slate-100 dark:bg-[#161920] select-none flex items-center">
            {/* Track Header Space spacer */}
            <div className="w-28 sm:w-36 md:w-44 shrink-0 px-3 border-r border-slate-200 dark:border-[#232731] flex items-center justify-between text-[11px] font-mono text-slate-600 dark:text-[#90949C] font-bold">
              <span>TRACKS</span>
              <span>SYNC</span>
            </div>

            {/* Time ruler ticks container */}
            <div 
              ref={timelineRef}
              onClick={handleTimelineClick}
              onMouseMove={handleDrag}
              className="flex-1 relative h-full cursor-pointer overflow-hidden"
            >
              {/* Ruler SVG */}
              <svg className="w-full h-full" preserveAspectRatio="none" viewBox="0 0 1000 36">
                <defs>
                  <pattern id="rulerTicks" width="50" height="36" patternUnits="userSpaceOnUse">
                    <line x1="0" y1="36" x2="0" y2="16" stroke="#94A3B8" strokeWidth="1" />
                    <line x1="10" y1="36" x2="10" y2="26" stroke="#CBD5E1" strokeWidth="1" />
                    <line x1="20" y1="36" x2="20" y2="26" stroke="#CBD5E1" strokeWidth="1" />
                    <line x1="30" y1="36" x2="30" y2="26" stroke="#CBD5E1" strokeWidth="1" />
                    <line x1="40" y1="36" x2="40" y2="26" stroke="#CBD5E1" strokeWidth="1" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#rulerTicks)" />
                {/* Time markers */}
                <text x="2%" y="14" fill="#64748B" fontSize="9" fontFamily="monospace">00:00:00</text>
                <text x="25%" y="14" fill="#64748B" fontSize="9" fontFamily="monospace">00:05:00</text>
                <text x="50%" y="14" fill="#64748B" fontSize="9" fontFamily="monospace">00:10:00</text>
                <text x="75%" y="14" fill="#64748B" fontSize="9" fontFamily="monospace">00:15:00</text>
                <text x="95%" y="14" fill="#64748B" fontSize="9" fontFamily="monospace">00:20:00</text>
              </svg>

              {/* Red/Yellow Playhead Needle */}
              <div 
                className="absolute top-0 bottom-0 w-0.5 bg-[#D97706] dark:bg-[#E5A93C] z-30 pointer-events-none transition-transform duration-75"
                style={{ left: `${playheadPercent}%` }}
              >
                <div className="w-3.5 h-3.5 -ml-1.5 bg-[#D97706] dark:bg-[#E5A93C] clip-playhead shadow-md" style={{ clipPath: 'polygon(0 0, 100% 0, 50% 100%)' }} />
              </div>
            </div>
          </div>

          {/* Tracks Stack */}
          <div className="divide-y divide-slate-200 dark:divide-[#1D2028] relative">
            {/* TRACK V3: Programming Guruji */}
            <div className="flex items-stretch min-h-[58px] bg-white dark:bg-[#101217] hover:bg-slate-50 dark:hover:bg-[#13151D] transition-colors">
              <div className="w-28 sm:w-36 md:w-44 shrink-0 px-3 py-2 border-r border-slate-200 dark:border-[#232731] bg-slate-50 dark:bg-[#14161C] flex flex-col justify-center">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded font-bold bg-[#C97B63] text-white">
                    V3
                  </span>
                  <span className="text-xs font-bold text-slate-900 dark:text-[#ECEAE5] truncate">
                    Tutorial / Tech
                  </span>
                </div>
                <span className="text-[10px] text-slate-500 dark:text-[#787D87] truncate mt-0.5 font-medium">
                  Programming Guruji
                </span>
              </div>

              {/* Track Content Lane */}
              <div 
                className="flex-1 p-1.5 relative flex items-center gap-1 overflow-x-auto cursor-pointer"
                onClick={handleTimelineClick}
              >
                {/* Playhead Guide in Track */}
                <div 
                  className="absolute top-0 bottom-0 w-0.5 bg-[#D97706] dark:bg-[#E5A93C] z-20 pointer-events-none"
                  style={{ left: `${playheadPercent}%` }}
                />

                {v3Clips.map((clip) => (
                  <button
                    key={clip.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      onPlayProject(clip);
                    }}
                    onMouseEnter={() => setHoveredClip(clip)}
                    onMouseLeave={() => setHoveredClip(null)}
                    className="flex-1 min-w-[140px] sm:min-w-[180px] h-10 px-2.5 rounded bg-[#C97B63]/10 hover:bg-[#C97B63]/25 border border-[#C97B63]/40 hover:border-[#C97B63] text-left transition-all relative group flex flex-col justify-center shadow-xs"
                  >
                    <div className="flex items-center justify-between text-[10px] font-mono text-[#C97B63] font-bold">
                      <span>{clip.projectNumber}</span>
                      <span>{clip.duration}</span>
                    </div>
                    <p className="text-[11px] font-bold text-slate-900 dark:text-[#ECEAE5] truncate">
                      {clip.title}
                    </p>
                    <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Play className="w-3 h-3 text-[#C97B63] fill-current" />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* TRACK V2: Gyani Brothers */}
            <div className="flex items-stretch min-h-[58px] bg-white dark:bg-[#101217] hover:bg-slate-50 dark:hover:bg-[#13151D] transition-colors">
              <div className="w-28 sm:w-36 md:w-44 shrink-0 px-3 py-2 border-r border-slate-200 dark:border-[#232731] bg-slate-50 dark:bg-[#14161C] flex flex-col justify-center">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded font-bold bg-[#0D9488] text-white">
                    V2
                  </span>
                  <span className="text-xs font-bold text-slate-900 dark:text-[#ECEAE5] truncate">
                    Commentary / Ent
                  </span>
                </div>
                <span className="text-[10px] text-slate-500 dark:text-[#787D87] truncate mt-0.5 font-medium">
                  Gyani Brothers (16:9)
                </span>
              </div>

              {/* Track Content Lane */}
              <div 
                className="flex-1 p-1.5 relative flex items-center gap-1 overflow-x-auto cursor-pointer"
                onClick={handleTimelineClick}
              >
                {/* Playhead Guide in Track */}
                <div 
                  className="absolute top-0 bottom-0 w-0.5 bg-[#D97706] dark:bg-[#E5A93C] z-20 pointer-events-none"
                  style={{ left: `${playheadPercent}%` }}
                />

                {v2Clips.map((clip) => (
                  <button
                    key={clip.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      onPlayProject(clip);
                    }}
                    onMouseEnter={() => setHoveredClip(clip)}
                    onMouseLeave={() => setHoveredClip(null)}
                    className="flex-1 min-w-[200px] h-10 px-2.5 rounded bg-teal-500/10 hover:bg-teal-500/25 border border-teal-500/40 hover:border-teal-500 text-left transition-all relative group flex flex-col justify-center shadow-xs"
                  >
                    <div className="flex items-center justify-between text-[10px] font-mono text-[#0D9488] dark:text-[#5FA8A0] font-bold">
                      <span>{clip.projectNumber}</span>
                      <span>{clip.duration}</span>
                    </div>
                    <p className="text-[11px] font-bold text-slate-900 dark:text-[#ECEAE5] truncate">
                      {clip.title}
                    </p>
                    <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Play className="w-3 h-3 text-[#0D9488] dark:text-[#5FA8A0] fill-current" />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* TRACK V1: Shorts & Reels (9:16) */}
            <div className="flex items-stretch min-h-[58px] bg-white dark:bg-[#101217] hover:bg-slate-50 dark:hover:bg-[#13151D] transition-colors">
              <div className="w-28 sm:w-36 md:w-44 shrink-0 px-3 py-2 border-r border-slate-200 dark:border-[#232731] bg-slate-50 dark:bg-[#14161C] flex flex-col justify-center">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded font-bold bg-[#D97706] text-white">
                    V1
                  </span>
                  <span className="text-xs font-bold text-slate-900 dark:text-[#ECEAE5] truncate">
                    Shorts &amp; Reels
                  </span>
                </div>
                <span className="text-[10px] text-slate-500 dark:text-[#787D87] truncate mt-0.5 font-medium">
                  Vertical 9:16 Retention
                </span>
              </div>

              {/* Track Content Lane */}
              <div 
                className="flex-1 p-1.5 relative flex items-center gap-1 overflow-x-auto cursor-pointer"
                onClick={handleTimelineClick}
              >
                {/* Playhead Guide in Track */}
                <div 
                  className="absolute top-0 bottom-0 w-0.5 bg-[#D97706] dark:bg-[#E5A93C] z-20 pointer-events-none"
                  style={{ left: `${playheadPercent}%` }}
                />

                {v1Clips.map((clip) => (
                  <button
                    key={clip.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      onPlayProject(clip);
                    }}
                    onMouseEnter={() => setHoveredClip(clip)}
                    onMouseLeave={() => setHoveredClip(null)}
                    className="flex-1 min-w-[200px] h-10 px-2.5 rounded bg-amber-500/10 hover:bg-amber-500/25 border border-amber-500/40 hover:border-amber-500 text-left transition-all relative group flex flex-col justify-center shadow-xs"
                  >
                    <div className="flex items-center justify-between text-[10px] font-mono text-[#D97706] dark:text-[#E5A93C] font-bold">
                      <span>{clip.projectNumber} · 9:16</span>
                      <span>{clip.duration}</span>
                    </div>
                    <p className="text-[11px] font-bold text-slate-900 dark:text-[#ECEAE5] truncate">
                      {clip.title}
                    </p>
                    <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Play className="w-3 h-3 text-[#D97706] dark:text-[#E5A93C] fill-current" />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* TRACK A1: Dialogue Sync & Noise Gate */}
            <div className="flex items-stretch min-h-[46px] bg-slate-50/60 dark:bg-[#0E1015]">
              <div className="w-28 sm:w-36 md:w-44 shrink-0 px-3 py-1.5 border-r border-slate-200 dark:border-[#232731] bg-slate-100 dark:bg-[#13151B] flex flex-col justify-center">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-mono px-1 py-0.2 rounded font-semibold bg-indigo-100 dark:bg-[#2B303C] text-indigo-700 dark:text-[#8EA2CD]">
                      A1
                    </span>
                    <span className="text-[11px] font-bold text-slate-800 dark:text-[#B0B4BC] truncate">
                      Dialogue Sync
                    </span>
                  </div>
                  <Volume2 className="w-3 h-3 text-indigo-600 dark:text-[#8EA2CD]" />
                </div>
                <span className="text-[9px] text-slate-500 dark:text-[#5F636C] font-mono mt-0.5">-14 LUFS Normalized</span>
              </div>

              {/* Waveform Visualization */}
              <div 
                className="flex-1 p-1 relative flex items-center overflow-hidden cursor-pointer"
                onClick={handleTimelineClick}
              >
                <div 
                  className="absolute top-0 bottom-0 w-0.5 bg-[#D97706] dark:bg-[#E5A93C] z-20 pointer-events-none"
                  style={{ left: `${playheadPercent}%` }}
                />
                <div className="w-full h-7 rounded bg-slate-200/60 dark:bg-[#171A22] border border-slate-300 dark:border-[#232731] flex items-center px-2 gap-1 overflow-hidden opacity-90">
                  {Array.from({ length: 48 }).map((_, idx) => {
                    const h = [20, 45, 75, 30, 90, 60, 40, 80, 50, 70, 35, 85, 25, 65, 95, 40][idx % 16];
                    return (
                      <div
                        key={idx}
                        className="flex-1 bg-indigo-500 dark:bg-[#8EA2CD] rounded-full"
                        style={{ height: `${h}%`, minWidth: '3px' }}
                      />
                    );
                  })}
                </div>
              </div>
            </div>

            {/* TRACK A2: SFX & Background Music Ducking */}
            <div className="flex items-stretch min-h-[46px] bg-slate-50/60 dark:bg-[#0E1015]">
              <div className="w-28 sm:w-36 md:w-44 shrink-0 px-3 py-1.5 border-r border-slate-200 dark:border-[#232731] bg-slate-100 dark:bg-[#13151B] flex flex-col justify-center">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-mono px-1 py-0.2 rounded font-semibold bg-amber-100 dark:bg-[#2B303C] text-amber-700 dark:text-[#D9A35F]">
                      A2
                    </span>
                    <span className="text-[11px] font-bold text-slate-800 dark:text-[#B0B4BC] truncate">
                      SFX &amp; Music Duck
                    </span>
                  </div>
                  <Volume2 className="w-3 h-3 text-amber-600 dark:text-[#D9A35F]" />
                </div>
                <span className="text-[9px] text-slate-500 dark:text-[#5F636C] font-mono mt-0.5">-18dB Duck on Speech</span>
              </div>

              {/* Waveform Visualization */}
              <div 
                className="flex-1 p-1 relative flex items-center overflow-hidden cursor-pointer"
                onClick={handleTimelineClick}
              >
                <div 
                  className="absolute top-0 bottom-0 w-0.5 bg-[#D97706] dark:bg-[#E5A93C] z-20 pointer-events-none"
                  style={{ left: `${playheadPercent}%` }}
                />
                <div className="w-full h-7 rounded bg-slate-200/60 dark:bg-[#171A22] border border-slate-300 dark:border-[#232731] flex items-center px-2 gap-1 overflow-hidden opacity-90">
                  {Array.from({ length: 48 }).map((_, idx) => {
                    const h = [10, 15, 35, 20, 45, 25, 15, 30, 20, 40, 20, 35, 15, 25, 45, 15][idx % 16];
                    return (
                      <div
                        key={idx}
                        className="flex-1 bg-amber-500 dark:bg-[#D9A35F] rounded-full"
                        style={{ height: `${h}%`, minWidth: '3px' }}
                      />
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Timeline Bottom Status & Clip Inspector Tooltip */}
          <div className="px-4 py-2.5 bg-slate-100 dark:bg-[#161920] border-t border-slate-200 dark:border-[#232731] flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-600 dark:text-[#90949C] gap-2">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-slate-900 dark:text-[#ECEAE5] font-bold">Timeline Ready</span>
              </span>
              <span>·</span>
              <span className="font-mono text-slate-600 dark:text-[#787D87]">
                {hoveredClip ? (
                  <span className="text-[#D97706] dark:text-[#E5A93C] font-bold">
                    Hovering: {hoveredClip.projectNumber} — {hoveredClip.title} ({hoveredClip.duration})
                  </span>
                ) : (
                  <span>Click any timeline clip to play full video in Screening Suite</span>
                )}
              </span>
            </div>

            <div className="flex items-center gap-3 text-[11px] font-mono text-slate-600 dark:text-[#787D87]">
              <span>SAMPLE RATE: 48kHz</span>
              <span>·</span>
              <span>TIMEBASE: 29.97 fps</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
