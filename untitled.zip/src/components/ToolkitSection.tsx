import React from 'react';
import { Video, Cpu, BookOpen } from 'lucide-react';

const TOP_TOOLS = [
  { name: 'Adobe Premiere Pro', role: 'Primary NLE', desc: 'Multi-cam, dynamic links & Lumetri' },
  { name: 'CapCut Pro', role: 'Short-Form', desc: 'Speed ramps & kinetic captioning' },
  { name: 'VN Video Editor', role: 'Mobile Fast Cut', desc: 'Keyframe curve control & PIP' },
  { name: 'Filmora & Audacity', role: 'Audio Master', desc: '-14 LUFS loudness & vocal EQ' },
  { name: 'Adobe Photoshop', role: 'Thumbnail CTR', desc: 'High-conversion YouTube packaging' },
  { name: 'AI Production Suite', role: 'Acceleration', desc: 'Auto-transcription & B-roll sourcing' }
];

export const ToolkitSection: React.FC = () => {
  return (
    <section id="toolkit" className="py-14 sm:py-20 border-b border-slate-200 dark:border-[#20242D] bg-slate-50 dark:bg-[#08090B] transition-colors">
      <div className="max-w-[1300px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-200 dark:border-[#20242D]">
          <div>
            <div className="text-xs sm:text-sm font-mono text-[#0D9488] dark:text-[#5FA8A0] uppercase tracking-wider mb-2 font-bold">
              EQUIPMENT &amp; NLE STACK
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-[#ECEAE5] font-display">
              Production Toolkit.
            </h2>
          </div>
        </div>

        {/* Big Punchy Tool Cards */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {TOP_TOOLS.map((t) => (
            <div
              key={t.name}
              className="bg-white dark:bg-[#12141A] border-2 border-slate-200 dark:border-[#232731] hover:border-[#0D9488] dark:hover:border-[#5FA8A0] p-5 rounded-2xl transition-all shadow-sm hover:shadow-md"
            >
              <div className="flex items-center justify-between text-xs font-mono mb-2">
                <span className="text-[#0D9488] dark:text-[#5FA8A0] font-bold uppercase">{t.role}</span>
                <span className="text-slate-500 dark:text-[#90949C]">PRO LEVEL</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-[#ECEAE5] font-display">
                {t.name}
              </h3>
              <p className="text-sm sm:text-base text-slate-700 dark:text-[#B0B4BC] mt-1 font-medium">
                {t.desc}
              </p>
            </div>
          ))}
        </div>

        {/* 3 Large Media Bin Columns */}
        <div className="mt-10 bg-white dark:bg-[#12141A] border-2 border-slate-200 dark:border-[#232731] rounded-2xl overflow-hidden grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-slate-200 dark:divide-[#232731] shadow-sm">
          <div className="p-6 sm:p-8 space-y-3">
            <div className="flex items-center gap-2 text-sm font-mono font-bold text-[#D97706] dark:text-[#E5A93C] uppercase">
              <Video className="w-5 h-5" />
              <span>Editing &amp; Social</span>
            </div>
            <ul className="space-y-2 text-base font-semibold text-slate-800 dark:text-[#D5D8E0]">
              <li>▶ Fast-Paced Jump Cuts &amp; Rhythm</li>
              <li>▶ Subtitle Typography (Sound-Off)</li>
              <li>▶ Comedic &amp; Hook Crash Zooms</li>
              <li>▶ Multi-Platform Safe-Zone Mastery</li>
            </ul>
          </div>

          <div className="p-6 sm:p-8 space-y-3">
            <div className="flex items-center gap-2 text-sm font-mono font-bold text-[#0D9488] dark:text-[#5FA8A0] uppercase">
              <Cpu className="w-5 h-5" />
              <span>Creative Suite</span>
            </div>
            <ul className="space-y-2 text-base font-semibold text-slate-800 dark:text-[#D5D8E0]">
              <li>▶ High-CTR Thumbnail Design</li>
              <li>▶ Adobe Premiere, CapCut &amp; VN</li>
              <li>▶ Audacity Noise &amp; Vocal Cleanup</li>
              <li>▶ Illustrator Vector Graphics</li>
            </ul>
          </div>

          <div className="p-6 sm:p-8 space-y-3">
            <div className="flex items-center gap-2 text-sm font-mono font-bold text-[#C97B63] uppercase">
              <BookOpen className="w-5 h-5" />
              <span>Social Strategy</span>
            </div>
            <ul className="space-y-2 text-base font-semibold text-slate-800 dark:text-[#D5D8E0]">
              <li>▶ 1.5s Hook Architecture</li>
              <li>▶ 500+ Students Mentored</li>
              <li>▶ 3 YouTube Channels Built</li>
              <li>▶ Fast Turnaround &amp; Retainers</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};
