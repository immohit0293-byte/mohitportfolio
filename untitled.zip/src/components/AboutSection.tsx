import React from 'react';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-14 sm:py-20 border-b border-slate-200 dark:border-[#20242D] bg-slate-50 dark:bg-[#0E1014] transition-colors">
      <div className="max-w-[1300px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-200 dark:border-[#20242D]">
          <div>
            <div className="text-xs sm:text-sm font-mono text-[#C97B63] uppercase tracking-wider mb-2 font-bold">
              BACKGROUND &amp; TRACK RECORD
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-[#ECEAE5] font-display">
              About Mohit Singh.
            </h2>
          </div>
        </div>

        <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Big Statement Block (Less text, bigger text) */}
          <div className="lg:col-span-7 space-y-6">
            <blockquote className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-[#ECEAE5] font-display leading-tight">
              "Running 3 YouTube channels and training 500+ creators taught me that <span className="text-gradient-shimmer">pacing is everything</span>."
            </blockquote>

            <p className="text-base sm:text-xl text-slate-700 dark:text-[#B0B4BC] font-medium leading-relaxed">
              Based in Noida, India. 5+ years crafting tutorial walkthroughs, vertical algorithm reels, and brand campaigns designed to maximize viewer watch-time.
            </p>

            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="p-4 bg-white dark:bg-[#14161C] border-2 border-slate-200 dark:border-[#232731] rounded-2xl shadow-sm">
                <span className="text-xs font-mono font-bold text-[#D97706] dark:text-[#E5A93C] uppercase block mb-1">
                  Retention Focus
                </span>
                <span className="text-base sm:text-lg font-bold text-slate-900 dark:text-[#ECEAE5]">
                  Zero dead air &amp; dynamic visual re-anchors every 3–5 seconds.
                </span>
              </div>
              <div className="p-4 bg-white dark:bg-[#14161C] border-2 border-slate-200 dark:border-[#232731] rounded-2xl shadow-sm">
                <span className="text-xs font-mono font-bold text-[#0D9488] dark:text-[#5FA8A0] uppercase block mb-1">
                  End-to-End Delivery
                </span>
                <span className="text-base sm:text-lg font-bold text-slate-900 dark:text-[#ECEAE5]">
                  A-roll to sound master (-14 LUFS) &amp; thumbnail packaging.
                </span>
              </div>
            </div>
          </div>

          {/* Timeline Cards (Punchy) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-5 bg-white dark:bg-[#14161C] border-2 border-slate-200 dark:border-[#282C38] rounded-2xl space-y-2 shadow-sm">
              <div className="flex items-center justify-between text-xs font-mono font-bold">
                <span className="text-[#D97706] dark:text-[#E5A93C]">2021 — PRESENT</span>
                <span className="text-emerald-600 dark:text-emerald-400">ACTIVE</span>
              </div>
              <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-[#ECEAE5] font-display">
                Video Editor &amp; Social Media Manager
              </h3>
              <p className="text-sm font-semibold text-slate-600 dark:text-[#90949C]">
                Programming Guruji · Gyani Brothers · ECC
              </p>
            </div>

            <div className="p-5 bg-white dark:bg-[#14161C] border-2 border-slate-200 dark:border-[#232731] rounded-2xl space-y-2 shadow-sm">
              <div className="flex items-center justify-between text-xs font-mono font-bold">
                <span className="text-[#0D9488] dark:text-[#5FA8A0]">2022 — 2026</span>
                <span className="text-slate-500 dark:text-[#90949C]">TRAINER LEAD</span>
              </div>
              <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-[#ECEAE5] font-display">
                Software Trainer &amp; Faculty Lead
              </h3>
              <p className="text-sm font-semibold text-slate-600 dark:text-[#90949C]">
                Education One Step Academy (500+ Mentored)
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
