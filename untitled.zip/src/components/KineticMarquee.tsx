import React, { useState, useEffect } from 'react';
import { Sparkles, Film, Play, Scissors, Layers } from 'lucide-react';

export const KineticMarquee: React.FC = () => {
  const [scrollSkew, setScrollSkew] = useState<number>(0);

  const marqueeItems = [
    'MOHIT SINGH',
    'VIDEO EDITOR',
    'SOCIAL MEDIA MANAGER',
    '200+ VIDEOS PUBLISHED',
    'RETENTION ARCHITECT',
    'PREMIERE PRO & CAPCUT',
    'ALGORITHM PACING'
  ];

  useEffect(() => {
    let lastY = window.scrollY;
    let timeoutId: number;

    const handleScroll = () => {
      const currentY = window.scrollY;
      const diff = currentY - lastY;
      lastY = currentY;
      // Clamp dynamic kinetic skew
      const skew = Math.max(-6, Math.min(6, diff * 0.08));
      setScrollSkew(skew);

      window.clearTimeout(timeoutId);
      timeoutId = window.setTimeout(() => {
        setScrollSkew(0);
      }, 120);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.clearTimeout(timeoutId);
    };
  }, []);

  return (
    <div className="relative py-6 sm:py-9 border-y border-slate-200 dark:border-[#20242D] bg-white dark:bg-[#0E1015] overflow-hidden select-none transition-colors">
      {/* Subtle background glow */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-20 dark:opacity-25"
        style={{
          background: 'radial-gradient(ellipse at 50% 50%, rgba(217,119,6,0.15) 0%, transparent 70%)'
        }}
      />

      {/* Marquee Track (Double repeat for seamless loop) with dynamic scroll skew */}
      <div 
        className="animate-marquee flex items-center gap-8 whitespace-nowrap transition-transform duration-150 ease-out will-change-transform"
        style={{
          transform: `skewX(${scrollSkew}deg)`
        }}
      >
        {[...marqueeItems, ...marqueeItems].map((item, idx) => (
          <div key={idx} className="flex items-center gap-8">
            <span className="text-6xl sm:text-8xl md:text-9xl lg:text-[7.5rem] font-black font-display tracking-tight text-slate-900 dark:text-[#ECEAE5] hover:text-[#D97706] dark:hover:text-[#E5A93C] transition-colors uppercase">
              {item === 'MOHIT SINGH' ? (
                <span className="text-gradient-shimmer">
                  MOHIT SINGH
                </span>
              ) : (
                item
              )}
            </span>
            <span className="text-2xl sm:text-3xl text-[#D97706]/70 dark:text-[#E5A93C]/70 font-mono">
              ★
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
