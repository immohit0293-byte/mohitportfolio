import React, { useState, useEffect } from 'react';
import { 
  X, 
  ExternalLink, 
  RotateCcw, 
  ChevronLeft, 
  ChevronRight, 
  Maximize2, 
  Sliders, 
  CheckCircle2, 
  Volume2, 
  Sparkles, 
  Clock, 
  Film,
  Play,
  Layers,
  Copy,
  Check
} from 'lucide-react';
import { VideoProject, VIDEO_PROJECTS } from '../data/projects';

interface VideoModalProps {
  project: VideoProject | null;
  onClose: () => void;
  onSelectProject: (proj: VideoProject) => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ 
  project, 
  onClose, 
  onSelectProject 
}) => {
  const [iframeKey, setIframeKey] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);
  const [theatreExpanded, setTheatreExpanded] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'breakdown' | 'playlist'>('breakdown');
  const [loadError, setLoadError] = useState<boolean>(false);

  useEffect(() => {
    setIframeKey(prev => prev + 1);
    setLoadError(false);
  }, [project?.id]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowRight' && project) {
        goToNext();
      } else if (e.key === 'ArrowLeft' && project) {
        goToPrev();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    if (project) {
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [project]);

  if (!project) return null;

  const currentIndex = VIDEO_PROJECTS.findIndex(p => p.id === project.id);
  const prevProject = currentIndex > 0 ? VIDEO_PROJECTS[currentIndex - 1] : VIDEO_PROJECTS[VIDEO_PROJECTS.length - 1];
  const nextProject = currentIndex < VIDEO_PROJECTS.length - 1 ? VIDEO_PROJECTS[currentIndex + 1] : VIDEO_PROJECTS[0];

  const goToNext = () => onSelectProject(nextProject);
  const goToPrev = () => onSelectProject(prevProject);

  const handleCopyLink = () => {
    const url = project.directUrl;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isShort = project.ratio === '9:16';

  // Format embed URLs cleanly
  const embedSourceUrl = project.source === 'youtube'
    ? `https://www.youtube-nocookie.com/embed/${project.youtubeId}?autoplay=1&rel=0&modestbranding=1&playsinline=1`
    : `https://drive.google.com/file/d/${project.driveId}/preview`;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 md:p-8 bg-black/85 backdrop-blur-md animate-fade-in"
      role="dialog"
      aria-modal="true"
      aria-label={`Playing ${project.title}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        className={`relative w-full ${
          theatreExpanded ? 'max-w-[1440px]' : 'max-w-6xl'
        } max-h-[92vh] flex flex-col bg-[#111317] border border-[#232731] rounded-xl shadow-2xl overflow-hidden transition-all duration-200`}
      >
        {/* Modal Top Control Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3 border-b border-[#20242D] bg-[#161920] shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <span 
              className="text-xs font-mono font-semibold px-2 py-0.5 rounded tracking-wide text-[#0B0C0E]"
              style={{ backgroundColor: project.trackColor }}
            >
              {project.trackId}
            </span>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-semibold text-[#ECEAE5] truncate">
                {project.title}
              </h2>
              <p className="text-xs text-[#90949C] hidden sm:block truncate">
                {project.trackName} · {project.duration} · {project.ratio === '9:16' ? 'Vertical 9:16' : '16:9 Widescreen'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Quick Playlist Nav */}
            <div className="hidden sm:flex items-center gap-1 bg-[#0E1014] border border-[#232731] rounded-lg p-0.5 mr-2">
              <button
                onClick={goToPrev}
                title="Previous Video (Left Arrow)"
                className="p-1.5 text-[#90949C] hover:text-[#ECEAE5] hover:bg-[#1C2028] rounded transition-colors"
                aria-label="Previous video"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-[11px] font-mono text-[#90949C] px-1.5">
                {currentIndex + 1} / {VIDEO_PROJECTS.length}
              </span>
              <button
                onClick={goToNext}
                title="Next Video (Right Arrow)"
                className="p-1.5 text-[#90949C] hover:text-[#ECEAE5] hover:bg-[#1C2028] rounded transition-colors"
                aria-label="Next video"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Reload button in case of stream delay */}
            <button
              onClick={() => {
                setIframeKey(k => k + 1);
                setLoadError(false);
              }}
              title="Reload Video Stream"
              className="p-2 text-[#90949C] hover:text-[#ECEAE5] hover:bg-[#20242D] rounded-lg transition-colors"
              aria-label="Reload video stream"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Theatre Mode Toggle */}
            <button
              onClick={() => setTheatreExpanded(!theatreExpanded)}
              title={theatreExpanded ? "Standard Mode" : "Expand Theatre View"}
              className="hidden md:inline-flex p-2 text-[#90949C] hover:text-[#ECEAE5] hover:bg-[#20242D] rounded-lg transition-colors"
              aria-label="Toggle theatre mode"
            >
              <Maximize2 className="w-4 h-4" />
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              title="Close Player (Esc)"
              className="p-2 text-[#90949C] hover:text-white hover:bg-red-500/20 hover:border-red-500/30 border border-transparent rounded-lg transition-colors ml-1"
              aria-label="Close video player"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Main Body (Video Viewport + Details Pane) */}
        <div className="flex-1 overflow-y-auto lg:overflow-hidden grid grid-cols-1 lg:grid-cols-12 bg-[#0E1014]">
          {/* Video Container Area */}
          <div className={`${theatreExpanded ? 'lg:col-span-8' : 'lg:col-span-8 xl:col-span-8'} flex flex-col items-center justify-center p-3 sm:p-5 bg-[#08090C] relative border-b lg:border-b-0 lg:border-r border-[#20242D] min-h-[380px] lg:min-h-[520px]`}>
            {/* Viewport Frame Box */}
            <div 
              className={`relative w-full rounded-lg overflow-hidden bg-black border border-[#20242D] shadow-inner flex items-center justify-center ${
                isShort 
                  ? 'max-w-[340px] aspect-[9/16] h-[70vh] max-h-[620px]' 
                  : 'w-full max-w-4xl aspect-[16/9]'
              }`}
            >
              {/* The Primary Video Iframe */}
              <iframe
                key={`${project.id}-${iframeKey}`}
                src={embedSourceUrl}
                title={project.title}
                className="w-full h-full border-0 absolute inset-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
                allowFullScreen
                referrerPolicy="strict-origin-when-cross-origin"
                onError={() => setLoadError(true)}
              />

              {/* Troubleshooting overlay for Google Drive / 3rd-party cookie issues */}
              {project.source === 'drive' && (
                <div className="absolute top-2 right-2 z-10">
                  <a
                    href={project.directUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-medium bg-[#161920]/90 hover:bg-[#E5A93C] text-[#ECEAE5] hover:text-[#0B0C0E] border border-[#2B2E36] rounded backdrop-blur-sm transition-colors shadow-lg"
                    title="Open directly on Google Drive"
                  >
                    <span>Drive Tab</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
            </div>

            {/* Quick Player Bar Under Video */}
            <div className="w-full max-w-4xl mt-3 flex items-center justify-between text-xs text-[#90949C] px-1">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <Film className="w-3.5 h-3.5 text-[#E5A93C]" />
                  <span>{project.ratio === '9:16' ? '9:16 Portrait' : '16:9 Landscape'}</span>
                </span>
                <span>·</span>
                <span>{project.targetPlatform}</span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={handleCopyLink}
                  className="inline-flex items-center gap-1 text-[#90949C] hover:text-[#ECEAE5] transition-colors"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied' : 'Share'}</span>
                </button>
                <span>·</span>
                <a
                  href={project.directUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[#E5A93C] hover:underline"
                >
                  <span>Open Source</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>

          {/* Right Inspector & Details Sidebar */}
          <div className={`${theatreExpanded ? 'lg:col-span-4' : 'lg:col-span-4 xl:col-span-4'} flex flex-col bg-[#14161C] border-t lg:border-t-0 border-[#20242D] max-h-[500px] lg:max-h-[750px] overflow-hidden`}>
            {/* Tab Header */}
            <div className="flex items-center border-b border-[#20242D] px-4 pt-2 shrink-0 bg-[#171A21]">
              <button
                onClick={() => setActiveTab('breakdown')}
                className={`pb-2.5 px-3 text-xs font-medium border-b-2 transition-colors ${
                  activeTab === 'breakdown'
                    ? 'border-[#E5A93C] text-[#ECEAE5]'
                    : 'border-transparent text-[#90949C] hover:text-[#ECEAE5]'
                }`}
              >
                Editor's Breakdown
              </button>
              <button
                onClick={() => setActiveTab('playlist')}
                className={`pb-2.5 px-3 text-xs font-medium border-b-2 transition-colors ${
                  activeTab === 'playlist'
                    ? 'border-[#E5A93C] text-[#ECEAE5]'
                    : 'border-transparent text-[#90949C] hover:text-[#ECEAE5]'
                }`}
              >
                Sequence Playlist ({VIDEO_PROJECTS.length})
              </button>
            </div>

            {/* Tab Contents */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 text-sm">
              {activeTab === 'breakdown' ? (
                <>
                  {/* Clip Info Card */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-mono text-[#90949C]">
                      <span>{project.projectNumber}</span>
                      <span className="text-[#E5A93C]">{project.cutsEstimate}</span>
                    </div>
                    <h3 className="text-base font-semibold text-[#ECEAE5] leading-snug">
                      {project.subtitle}
                    </h3>
                    <p className="text-xs sm:text-sm text-[#B0B4BC] leading-relaxed">
                      {project.description}
                    </p>
                  </div>

                  {/* Social Media Strategy Card if available */}
                  {project.socialManagerStrategy && (
                    <div className="p-3 rounded-lg bg-[#181B22] border border-[#252935] space-y-2">
                      <span className="text-xs font-mono font-semibold text-[#E5A93C] uppercase tracking-wider block">
                        Social Media Manager Strategy:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <div className="bg-[#12141A] p-2 rounded">
                          <b className="text-[#90949C] block text-[10px] font-mono">OBJECTIVE</b>
                          <span className="text-[#ECEAE5]">{project.socialManagerStrategy.objective}</span>
                        </div>
                        <div className="bg-[#12141A] p-2 rounded">
                          <b className="text-[#90949C] block text-[10px] font-mono">RETENTION TACTIC</b>
                          <span className="text-[#ECEAE5]">{project.socialManagerStrategy.retentionTactic}</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Editing Highlights Checklist */}
                  <div className="space-y-2.5 border-t border-[#232731] pt-4">
                    <h4 className="text-xs font-mono font-semibold text-[#ECEAE5] flex items-center gap-1.5 uppercase tracking-wider">
                      <Sparkles className="w-3.5 h-3.5 text-[#E5A93C]" />
                      <span>Post-Production Highlights</span>
                    </h4>
                    <div className="space-y-2">
                      {project.editHighlights.map((hl, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-xs text-[#C5C8CF] leading-relaxed">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{hl}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Technical Anatomy Grid */}
                  <div className="space-y-2.5 border-t border-[#232731] pt-4">
                    <h4 className="text-xs font-mono font-semibold text-[#ECEAE5] flex items-center gap-1.5 uppercase tracking-wider">
                      <Sliders className="w-3.5 h-3.5 text-[#5FA8A0]" />
                      <span>Technical Breakdown</span>
                    </h4>
                    <div className="grid grid-cols-1 gap-2 text-xs">
                      <div className="bg-[#1A1D24] p-2.5 rounded border border-[#252934]">
                        <span className="font-semibold text-[#E5A93C] block mb-0.5">Hook Architecture:</span>
                        <span className="text-[#9CA1AC]">{project.keyTechniques.hook}</span>
                      </div>
                      <div className="bg-[#1A1D24] p-2.5 rounded border border-[#252934]">
                        <span className="font-semibold text-[#5FA8A0] block mb-0.5">Audio Mastering:</span>
                        <span className="text-[#9CA1AC]">{project.keyTechniques.audio}</span>
                      </div>
                      <div className="bg-[#1A1D24] p-2.5 rounded border border-[#252934]">
                        <span className="font-semibold text-[#C97B63] block mb-0.5">Visual Framing & Pacing:</span>
                        <span className="text-[#9CA1AC]">{project.keyTechniques.visuals}</span>
                      </div>
                    </div>
                  </div>

                  {/* Software Stack */}
                  <div className="border-t border-[#232731] pt-4">
                    <h4 className="text-xs font-mono font-semibold text-[#90949C] uppercase tracking-wider mb-2">
                      Software Employed
                    </h4>
                    <div className="flex flex-wrap gap-1.5">
                      {project.toolsUsed.map((tool, i) => (
                        <span
                          key={i}
                          className="text-xs px-2 py-1 bg-[#1A1D24] border border-[#2A2E3B] text-[#D5D8E0] rounded"
                        >
                          {tool}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="border-t border-[#232731] pt-4 flex gap-2">
                    <a
                      href={project.directUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 py-2 px-3 text-xs font-semibold text-[#0B0C0E] bg-[#E5A93C] hover:bg-[#F2B705] rounded flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <span>{project.source === 'youtube' ? 'Open in YouTube' : 'Open in Google Drive'}</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                    <button
                      onClick={handleCopyLink}
                      className="py-2 px-3 text-xs font-medium text-[#ECEAE5] bg-[#1F222A] hover:bg-[#282C35] border border-[#2E333F] rounded flex items-center gap-1 transition-colors"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </>
              ) : (
                /* Sequence Playlist View */
                <div className="space-y-2">
                  <div className="text-xs text-[#90949C] mb-2 font-mono">
                    SELECT CLIP TO QUEUE IN SCREENING DECK:
                  </div>
                  {VIDEO_PROJECTS.map((proj, idx) => {
                    const isSelected = proj.id === project.id;
                    return (
                      <button
                        key={proj.id}
                        onClick={() => onSelectProject(proj)}
                        className={`w-full flex items-center gap-3 p-2 rounded text-left transition-all border ${
                          isSelected
                            ? 'bg-[#1F2430] border-[#E5A93C]/50 text-white'
                            : 'bg-[#151820] border-[#20242D] text-[#B0B4BC] hover:bg-[#1A1E27] hover:text-[#ECEAE5]'
                        }`}
                      >
                        <span 
                          className="w-1.5 self-stretch rounded-full shrink-0"
                          style={{ backgroundColor: proj.trackColor }}
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between text-[11px] font-mono text-[#90949C]">
                            <span>{proj.projectNumber} · {proj.trackId}</span>
                            <span>{proj.duration}</span>
                          </div>
                          <p className="text-xs font-medium text-[#ECEAE5] truncate">
                            {proj.title}
                          </p>
                          <p className="text-[11px] text-[#787D87] truncate">
                            {proj.ratio === '9:16' ? 'Vertical Short' : 'Widescreen 16:9'} · {proj.cutsEstimate}
                          </p>
                        </div>
                        {isSelected && (
                          <span className="w-2 h-2 rounded-full bg-[#E5A93C] shrink-0 animate-pulse" />
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Bottom Bar Navigation for Quick Prev/Next */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-2.5 border-t border-[#20242D] bg-[#12141A] text-xs text-[#90949C] shrink-0">
          <button
            onClick={goToPrev}
            className="flex items-center gap-1.5 text-[#B0B4BC] hover:text-white transition-colors py-1"
          >
            <ChevronLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Previous:</span>
            <span className="font-mono text-[#E5A93C] truncate max-w-[120px] sm:max-w-[180px]">
              {prevProject.projectNumber}
            </span>
          </button>

          <span className="font-mono text-[11px] text-[#70747E]">
            USE KEYBOARD ← / → TO CYCLE PROJECTS
          </span>

          <button
            onClick={goToNext}
            className="flex items-center gap-1.5 text-[#B0B4BC] hover:text-white transition-colors py-1"
          >
            <span className="hidden sm:inline">Next:</span>
            <span className="font-mono text-[#E5A93C] truncate max-w-[120px] sm:max-w-[180px]">
              {nextProject.projectNumber}
            </span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
