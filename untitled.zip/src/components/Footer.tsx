import React from 'react';
import { Mail, Phone, ExternalLink, ArrowUp } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-slate-200 dark:border-[#20242D] bg-white dark:bg-[#08090C] py-12 sm:py-16 text-sm text-slate-600 dark:text-[#90949C] transition-colors">
      <div className="max-w-[1300px] mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-8 border-b border-slate-200 dark:border-[#1A1D24]">
          <div className="space-y-1">
            <span className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-[#ECEAE5] font-display">
              MOHIT SINGH<span className="text-[#D97706] dark:text-[#E5A93C]">.</span>
            </span>
            <p className="text-xs text-slate-500 dark:text-[#787D87] font-medium">
              Video Editor &amp; Social Media Manager · Noida, Uttar Pradesh, India
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs font-semibold text-slate-700 dark:text-[#B0B4BC]">
            <a href="#hero" className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors">Billboard</a>
            <a href="#recent" className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors">Drive Vault</a>
            <a href="#work" className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors">Selected Work</a>
            <a href="#timeline" className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors">NLE Sequence</a>
            <a href="#toolkit" className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors">Toolkit</a>
            <a href="#about" className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors">About</a>
            <a href="#contact" className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors">Contact</a>
            <button
              onClick={scrollToTop}
              className="inline-flex items-center gap-1 text-[#D97706] dark:text-[#E5A93C] font-bold hover:underline"
              aria-label="Scroll to top"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-slate-500 dark:text-[#5F636C]">
          <div className="flex flex-wrap items-center gap-4">
            <span>© {new Date().getFullYear()} Mohit Singh. All rights reserved.</span>
            <span>·</span>
            <a 
              href="mailto:im.mohit0293@gmail.com" 
              className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors font-medium"
            >
              im.mohit0293@gmail.com
            </a>
            <span>·</span>
            <a 
              href="tel:+917428181376" 
              className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors font-medium"
            >
              +91 7428181376
            </a>
          </div>

          <div className="flex items-center gap-3">
            <a
              href="https://eonestep.in"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-slate-900 dark:hover:text-[#ECEAE5] transition-colors inline-flex items-center gap-1 font-semibold text-[#D97706] dark:text-[#E5A93C]"
            >
              <span>Design Portfolio (eonestep.in)</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
