import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  ChevronLeft, 
  ChevronRight, 
  ExternalLink, 
  Sparkles, 
  Film, 
  Volume2, 
  ArrowRight,
  TrendingUp,
  Clock,
  Layers
} from 'lucide-react';
import { VideoProject, VIDEO_PROJECTS } from '../data/projects';

interface HeroProps {
  onPlayFeatured: (project: VideoProject) => void;
  onExploreWork: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onPlayFeatured, onExploreWork }) => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(true);
  const [progress, setProgress] = useState<number>(0);
  const [scrollY, setScrollY] = useState<number>(0);

  const activeVideo = VIDEO_PROJECTS[currentIdx];

  // Scroll listener for dynamic kinetic animation on MOHIT SINGH
  useEffect(() => {
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          setScrollY(window.scrollY);
          ticking = false;
        });
        ticking = true;
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // 5-second auto-changing video cycle across all available portfolio videos
  useEffect(() => {
    if (!isAutoPlaying) return;

    const intervalTime = 5000;
    const tickInterval = 50;
    const step = (tickInterval / intervalTime) * 100;

    const intervalId = window.setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          setCurrentIdx((curr) => (curr + 1) % VIDEO_PROJECTS.length);
          return 0;
        }
        return prev + step;
      });
    }, tickInterval);

    return () => clearInterval(intervalId);
  }, [isAutoPlaying]);

  const handleNext = () => {
    setCurrentIdx((prev) => (prev + 1) % VIDEO_PROJECTS.length);
    setProgress(0);
  };

  const handlePrev = () => {
    setCurrentIdx((prev) => (prev - 1 + VIDEO_PROJECTS.length) % VIDEO_PROJECTS.length);
    setProgress(0);
  };

  return (
    <section id="hero" className="relative pt-6 pb-12 sm:pt-10 sm:pb-16 border-b border-slate-200 dark:border-[#222631] overflow-hidden bg-slate-50 dark:bg-[#090A0D] transition-colors">
      {/* Background Ambient Aura */}
      <div 
        className="absolute top-[-100px] right-[-50px] w-[500px] h-[500px] rounded-full pointer-events-none opacity-20 dark:opacity-25 blur-[100px]"
        style={{ background: 'radial-gradient(circle, #D97706 0%, #0D9488 50%, transparent 75%)' }}
      />

      <div className="max-w-[1340px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* AMUXO STREAMING BILLBOARD (Split-Hero Grid) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
          
          {/* Left Column: Big Bold Typography & Minimal High-Impact Text */}
          <div className="lg:col-span-7 space-y-5">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#D97706] dark:text-[#E5A93C] uppercase tracking-wider">
              <span className="w-2.5 h-2.5 rounded-full bg-[#D97706] dark:bg-[#E5A93C] animate-ping" />
              <span>AMUXO EDITING SUITE · NOW STREAMING</span>
            </div>

            {/* VERY LARGE ANIMATING NAME & HEADLINE (DYNAMIC SCROLL ANIMATION) */}
            <div className="overflow-visible py-1">
              <div 
                className="text-6xl sm:text-8xl md:text-9xl lg:text-[7.5rem] xl:text-[9.5rem] 2xl:text-[11rem] font-black tracking-tighter leading-[0.88] font-display select-none transition-transform duration-75 will-change-transform"
                style={{
                  transform: `translate3d(0, ${Math.min(scrollY * 0.16, 120)}px, 0) scale(${1 + Math.min(scrollY * 0.0004, 0.12)})`,
                  letterSpacing: `${-0.04 + Math.min(scrollY * 0.00008, 0.05)}em`,
                  filter: `drop-shadow(0 ${Math.min(scrollY * 0.06, 25)}px ${Math.min(scrollY * 0.09, 35)}px rgba(217, 119, 6, 0.45))`
                }}
              >
                <span className="text-gradient-shimmer block">
                  MOHIT SINGH
                </span>
              </div>
              <h1 className="text-2xl sm:text-4xl lg:text-5xl font-bold text-slate-900 dark:text-[#ECEAE5] tracking-tight mt-3 leading-[1.08]">
                Video Editor &amp; Social Media Manager.
              </h1>
            </div>

            {/* Big Punchy Takeaway */}
            <p className="text-lg sm:text-2xl text-slate-700 dark:text-[#C5C8CF] font-medium leading-snug max-w-xl">
              High-velocity viral reels &amp; long-form masterclasses engineered for platform watch time.
            </p>

            {/* Big Action CTAs */}
            <div className="flex flex-wrap items-center gap-3.5 pt-1">
              <button
                onClick={() => onPlayFeatured(activeVideo)}
                className="inline-flex items-center gap-2.5 px-6 py-3.5 text-base font-bold text-white dark:text-black bg-[#D97706] hover:bg-[#B45309] dark:bg-[#E5A93C] dark:hover:bg-[#F2B705] rounded-xl transition-transform hover:scale-103 shadow-lg group"
              >
                <Play className="w-5 h-5 fill-current" />
                <span>Screen Active Cut</span>
              </button>

              <button
                onClick={onExploreWork}
                className="inline-flex items-center gap-2 px-6 py-3.5 text-base font-bold text-slate-800 dark:text-[#ECEAE5] bg-white hover:bg-slate-100 dark:bg-[#14161C] dark:hover:bg-[#1E222B] border border-slate-200 dark:border-[#2B2E36] rounded-xl transition-colors shadow-sm"
              >
                <span>Browse Drive Vault</span>
                <ArrowRight className="w-4 h-4 text-[#D97706] dark:text-[#E5A93C]" />
              </button>
            </div>
          </div>

          {/* Right Column: 5-SECOND AUTO-CHANGING STREAMING BILLBOARD CARD */}
          <div className="lg:col-span-5">
            <div 
              className="bg-white dark:bg-[#111317] border-2 border-slate-200 dark:border-[#262A34] hover:border-[#D97706] dark:hover:border-[#E5A93C] rounded-2xl p-4 shadow-xl dark:shadow-2xl relative transition-all group/box"
              onMouseEnter={() => setIsAutoPlaying(false)}
              onMouseLeave={() => setIsAutoPlaying(true)}
            >
              {/* Header with 5s Automation Timer */}
              <div className="flex items-center justify-between pb-2.5 px-1 border-b border-slate-200 dark:border-[#20242D] text-xs font-mono">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#D97706] dark:bg-[#E5A93C] animate-pulse" />
                  <span className="text-slate-900 dark:text-[#ECEAE5] font-bold uppercase tracking-wider">
                    AUTO-REEL (5s CYCLE)
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsAutoPlaying(!isAutoPlaying)}
                    className="p-1 text-slate-500 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-white rounded bg-slate-100 dark:bg-[#1A1D24] border border-slate-200 dark:border-[#2A2E38]"
                    title={isAutoPlaying ? "Pause 2s Auto-Cycle" : "Resume 2s Auto-Cycle"}
                  >
                    {isAutoPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                  </button>
                  <span className="text-[#D97706] dark:text-[#E5A93C] font-bold tabular-nums">
                    {String(currentIdx + 1).padStart(2, '0')} / {String(VIDEO_PROJECTS.length).padStart(2, '0')}
                  </span>
                </div>
              </div>

              {/* 2-Second Progress Line */}
              <div className="w-full bg-slate-200 dark:bg-[#1C2028] h-1.5 rounded-full overflow-hidden my-2.5">
                <div 
                  className="bg-[#D97706] dark:bg-[#E5A93C] h-full transition-all duration-75"
                  style={{ width: `${progress}%` }}
                />
              </div>

              {/* Active Video Screen Box */}
              <div 
                onClick={() => onPlayFeatured(activeVideo)}
                className="relative aspect-[16/10] sm:aspect-[16/9] bg-black rounded-xl overflow-hidden cursor-pointer border border-slate-200 dark:border-[#232731] flex items-center justify-center group/screen shadow-inner"
              >
                <img
                  key={activeVideo.id}
                  src={activeVideo.thumbnail}
                  alt={activeVideo.title}
                  className="w-full h-full object-cover transition-all duration-300 transform group-hover/screen:scale-105"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    if (activeVideo.fallbackThumbnail && e.currentTarget.src !== activeVideo.fallbackThumbnail) {
                      e.currentTarget.src = activeVideo.fallbackThumbnail;
                    }
                  }}
                />

                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-black/30 pointer-events-none" />

                {/* Center Play Icon */}
                <div className="absolute z-10 w-16 h-16 rounded-full bg-[#D97706] dark:bg-[#E5A93C] text-white dark:text-black flex items-center justify-center shadow-2xl group-hover/screen:scale-110 transition-transform">
                  <Play className="w-7 h-7 fill-current ml-0.5" />
                </div>

                {/* Badges */}
                <div className="absolute top-3 left-3 z-10 flex items-center gap-2">
                  <span 
                    className="text-xs font-mono font-bold px-2 py-0.5 rounded text-white dark:text-black shadow-sm"
                    style={{ backgroundColor: activeVideo.trackColor }}
                  >
                    {activeVideo.fileName || activeVideo.projectNumber}
                  </span>
                </div>

                {/* Bottom Overlay Info */}
                <div className="absolute bottom-3 left-3 right-3 z-10 flex items-end justify-between">
                  <div className="min-w-0 pr-2">
                    <span className="text-xs font-mono text-[#E5A93C] uppercase tracking-wider block font-bold">
                      {activeVideo.ratio === '9:16' ? '9:16 Vertical Reel' : '16:9 Widescreen'}
                    </span>
                    <h3 className="text-base sm:text-lg font-bold text-white leading-tight truncate">
                      {activeVideo.title}
                    </h3>
                  </div>

                  <span className="text-xs font-mono font-bold bg-[#D97706] dark:bg-[#E5A93C] text-white dark:text-black px-2.5 py-1 rounded shadow-md shrink-0">
                    Play ▶
                  </span>
                </div>
              </div>

              {/* Stepper & Controls */}
              <div className="mt-3 flex items-center justify-between text-xs text-slate-600 dark:text-[#90949C]">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePrev}
                    className="p-1.5 rounded bg-slate-100 hover:bg-slate-200 dark:bg-[#1C2028] dark:hover:bg-[#282C35] text-slate-800 dark:text-[#ECEAE5] transition-colors"
                    aria-label="Previous featured video"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleNext}
                    className="p-1.5 rounded bg-slate-100 hover:bg-slate-200 dark:bg-[#1C2028] dark:hover:bg-[#282C35] text-slate-800 dark:text-[#ECEAE5] transition-colors"
                    aria-label="Next featured video"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  <span className="text-xs font-mono font-semibold text-slate-700 dark:text-[#B0B4BC] truncate max-w-[160px] sm:max-w-[200px]">
                    {activeVideo.cutsEstimate}
                  </span>
                </div>

                <span className="text-xs font-mono font-bold text-[#D97706] dark:text-[#E5A93C]">
                  {isAutoPlaying ? 'AUTOCYCLE: 5.0s' : 'PAUSED'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Big Bold Stats (Amuxo Style Glass Counters) */}
        <div className="mt-10 pt-8 border-t border-slate-200 dark:border-[#222631] grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="p-4 bg-white dark:bg-[#111317] border border-slate-200 dark:border-[#232731] rounded-xl shadow-sm">
            <span className="block text-4xl sm:text-5xl font-extrabold font-display text-[#D97706] dark:text-[#E5A93C] tabular-nums">
              5+ YRS
            </span>
            <span className="text-sm sm:text-base font-bold text-slate-900 dark:text-[#ECEAE5] block mt-1">
              Editing &amp; Social Media
            </span>
          </div>

          <div className="p-4 bg-white dark:bg-[#111317] border border-slate-200 dark:border-[#232731] rounded-xl shadow-sm">
            <span className="block text-4xl sm:text-5xl font-extrabold font-display text-[#0D9488] dark:text-[#5FA8A0] tabular-nums">
              200+
            </span>
            <span className="text-sm sm:text-base font-bold text-slate-900 dark:text-[#ECEAE5] block mt-1">
              Episodes Published
            </span>
          </div>

          <div className="p-4 bg-white dark:bg-[#111317] border border-slate-200 dark:border-[#232731] rounded-xl shadow-sm">
            <span className="block text-4xl sm:text-5xl font-extrabold font-display text-[#E11D48] dark:text-[#C97B63] tabular-nums">
              3
            </span>
            <span className="text-sm sm:text-base font-bold text-slate-900 dark:text-[#ECEAE5] block mt-1">
              Channels Managed
            </span>
          </div>

          <div className="p-4 bg-white dark:bg-[#111317] border border-slate-200 dark:border-[#232731] rounded-xl shadow-sm">
            <span className="block text-4xl sm:text-5xl font-extrabold font-display text-[#7C3AED] dark:text-[#9B8CD9] tabular-nums">
              500+
            </span>
            <span className="text-sm sm:text-base font-bold text-slate-900 dark:text-[#ECEAE5] block mt-1">
              Creators Mentored
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
