import React, { useState } from 'react';
import { Play, ExternalLink, CheckCircle2 } from 'lucide-react';
import { VideoProject, VIDEO_PROJECTS } from '../data/projects';

interface SelectedWorkProps {
  onPlayProject: (project: VideoProject) => void;
}

export const SelectedWork: React.FC<SelectedWorkProps> = ({ onPlayProject }) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'V1' | 'V2' | 'V3'>('all');

  const filteredProjects = activeFilter === 'all'
    ? VIDEO_PROJECTS
    : activeFilter === 'V1'
      ? VIDEO_PROJECTS.filter(p => p.trackId === 'V1' || p.trackId === 'DRIVE')
      : VIDEO_PROJECTS.filter(p => p.trackId === activeFilter);

  const shorts = filteredProjects.filter(p => p.trackId === 'V1' || p.trackId === 'DRIVE');
  const gyani = filteredProjects.filter(p => p.trackId === 'V2');
  const programming = filteredProjects.filter(p => p.trackId === 'V3');

  return (
    <section id="work" className="py-14 sm:py-20 border-b border-slate-200 dark:border-[#20242D] bg-slate-50 dark:bg-[#08090B] transition-colors">
      <div className="max-w-[1300px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header: Big Bold Text, Less Wordiness */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-slate-200 dark:border-[#20242D]">
          <div>
            <div className="text-xs sm:text-sm font-mono text-[#D97706] dark:text-[#E5A93C] uppercase tracking-wider mb-2 font-bold">
              CATALOGUE · 3 PRODUCTION TRACKS
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-[#ECEAE5] font-display">
              Selected Video Work.
            </h2>
            <p className="text-base sm:text-xl text-slate-700 dark:text-[#B0B4BC] mt-2 font-medium max-w-xl">
              14 master cuts across social reels, commentary &amp; tech tutorials.
            </p>
          </div>

          {/* Interactive Filter Tabs */}
          <div className="flex flex-wrap items-center gap-2 p-1.5 bg-white dark:bg-[#14161C] border border-slate-200 dark:border-[#232731] rounded-xl shrink-0 shadow-sm">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors whitespace-nowrap ${
                activeFilter === 'all'
                  ? 'bg-[#D97706] text-white dark:bg-[#E5A93C] dark:text-[#0B0C0E] shadow-sm'
                  : 'text-slate-600 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-[#ECEAE5]'
              }`}
            >
              All ({VIDEO_PROJECTS.length})
            </button>
            <button
              onClick={() => setActiveFilter('V1')}
              className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors whitespace-nowrap ${
                activeFilter === 'V1'
                  ? 'bg-[#D97706] text-white dark:bg-[#E5A93C] dark:text-[#0B0C0E] shadow-sm'
                  : 'text-slate-600 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-[#ECEAE5]'
              }`}
            >
              Shorts &amp; Reels (8)
            </button>
            <button
              onClick={() => setActiveFilter('V2')}
              className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors whitespace-nowrap ${
                activeFilter === 'V2'
                  ? 'bg-[#0D9488] text-white dark:bg-[#5FA8A0] dark:text-[#0B0C0E] shadow-sm'
                  : 'text-slate-600 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-[#ECEAE5]'
              }`}
            >
              Gyani Brothers (2)
            </button>
            <button
              onClick={() => setActiveFilter('V3')}
              className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors whitespace-nowrap ${
                activeFilter === 'V3'
                  ? 'bg-[#C97B63] text-white dark:bg-[#C97B63] dark:text-[#0B0C0E] shadow-sm'
                  : 'text-slate-600 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-[#ECEAE5]'
              }`}
            >
              Programming Guruji (4)
            </button>
          </div>
        </div>

        {/* TRACK V1: Shorts & Reels (9:16 Vertical Cuts) */}
        {(activeFilter === 'all' || activeFilter === 'V1') && shorts.length > 0 && (
          <div className="mt-12">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-[#20242D] mb-6">
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-[#D97706] text-white dark:bg-[#E5A93C] dark:text-[#0B0C0E]">
                  V1
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-[#ECEAE5] font-display">
                  Shorts &amp; Reels — 9:16
                </h3>
              </div>
              <span className="text-xs font-mono text-slate-500 dark:text-[#90949C] font-semibold">
                {shorts.length} Vertical Cuts
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {shorts.map((project) => (
                <div
                  key={project.id}
                  className="bg-white dark:bg-[#12141A] border-2 border-slate-200 dark:border-[#232731] hover:border-[#D97706] dark:hover:border-[#E5A93C] rounded-2xl overflow-hidden transition-all duration-200 group flex flex-col shadow-md hover:shadow-xl"
                >
                  {/* Smartphone 9:16 Frame */}
                  <div className="relative aspect-[9/16] max-h-[380px] bg-black overflow-hidden flex items-center justify-center">
                    <img
                      src={project.thumbnail}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        if (project.fallbackThumbnail && e.currentTarget.src !== project.fallbackThumbnail) {
                          e.currentTarget.src = project.fallbackThumbnail;
                        }
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/40 pointer-events-none" />

                    <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5">
                      <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-[#D97706] text-white dark:bg-[#E5A93C] dark:text-[#0B0C0E]">
                        {project.fileName || project.projectNumber}
                      </span>
                      <span className="text-xs font-mono px-2 py-0.5 rounded bg-black/70 text-white border border-white/10">
                        {project.duration}
                      </span>
                    </div>

                    <button
                      onClick={() => onPlayProject(project)}
                      className="absolute z-10 w-16 h-16 rounded-full bg-[#D97706] dark:bg-[#E5A93C] text-white dark:text-[#0B0C0E] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform"
                      aria-label={`Play ${project.title}`}
                    >
                      <Play className="w-7 h-7 fill-current ml-1" />
                    </button>
                  </div>

                  {/* Card Content (Punchy & Bold) */}
                  <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      <h4 className="text-base sm:text-lg font-bold text-slate-900 dark:text-[#ECEAE5] group-hover:text-[#D97706] dark:group-hover:text-[#E5A93C] transition-colors leading-snug">
                        {project.title}
                      </h4>
                      <p className="text-xs font-mono text-[#D97706] dark:text-[#E5A93C] mt-1 font-semibold">
                        {project.cutsEstimate}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-[#20242D] text-xs">
                      <button
                        onClick={() => onPlayProject(project)}
                        className="font-bold text-[#D97706] dark:text-[#E5A93C] hover:opacity-80 flex items-center gap-1.5"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Play Video</span>
                      </button>
                      <a
                        href={project.directUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-slate-500 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-white font-mono flex items-center gap-1"
                      >
                        <span>Drive</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TRACK V2: Gyani Brothers */}
        {(activeFilter === 'all' || activeFilter === 'V2') && gyani.length > 0 && (
          <div className="mt-14">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-[#20242D] mb-6">
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-[#0D9488] text-white dark:bg-[#5FA8A0] dark:text-[#0B0C0E]">
                  V2
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-[#ECEAE5] font-display">
                  Gyani Brothers — 16:9 Long-Form
                </h3>
              </div>
              <span className="text-xs font-mono text-slate-500 dark:text-[#90949C] font-semibold">
                Entertainment &amp; Pacing
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {gyani.map((project) => (
                <div
                  key={project.id}
                  className="bg-white dark:bg-[#12141A] border-2 border-slate-200 dark:border-[#232731] hover:border-[#0D9488] dark:hover:border-[#5FA8A0] rounded-2xl overflow-hidden transition-all duration-200 group flex flex-col shadow-md hover:shadow-xl"
                >
                  <div className="relative aspect-[16/9] bg-black overflow-hidden flex items-center justify-center">
                    <img
                      src={project.thumbnail}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/30 pointer-events-none" />

                    <div className="absolute top-3 left-3 z-10 flex items-center gap-2">
                      <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-[#0D9488] text-white dark:bg-[#5FA8A0] dark:text-[#0B0C0E]">
                        {project.projectNumber}
                      </span>
                      <span className="text-xs font-mono px-2 py-0.5 rounded bg-black/70 text-white">
                        {project.duration}
                      </span>
                    </div>

                    <button
                      onClick={() => onPlayProject(project)}
                      className="absolute z-10 w-16 h-16 rounded-full bg-[#0D9488] dark:bg-[#5FA8A0] text-white dark:text-[#0B0C0E] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform"
                      aria-label={`Play ${project.title}`}
                    >
                      <Play className="w-7 h-7 fill-current ml-1" />
                    </button>
                  </div>

                  <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      <h4 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-[#ECEAE5] font-display group-hover:text-[#0D9488] dark:group-hover:text-[#5FA8A0] transition-colors leading-tight">
                        {project.title}
                      </h4>
                      <p className="text-xs font-mono text-[#0D9488] dark:text-[#5FA8A0] mt-1 font-semibold">
                        {project.cutsEstimate} · {project.subtitle}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-[#20242D] text-xs">
                      <button
                        onClick={() => onPlayProject(project)}
                        className="font-bold text-[#0D9488] dark:text-[#5FA8A0] hover:opacity-80 text-sm flex items-center gap-1.5"
                      >
                        <Play className="w-4 h-4 fill-current" />
                        <span>Watch Video</span>
                      </button>
                      <a
                        href={project.directUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-slate-500 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-white font-mono flex items-center gap-1"
                      >
                        <span>YouTube</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TRACK V3: Programming Guruji */}
        {(activeFilter === 'all' || activeFilter === 'V3') && programming.length > 0 && (
          <div className="mt-14">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-[#20242D] mb-6">
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-[#C97B63] text-white dark:text-[#0B0C0E]">
                  V3
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-[#ECEAE5] font-display">
                  Programming Guruji — Tech Masterclasses
                </h3>
              </div>
              <span className="text-xs font-mono text-slate-500 dark:text-[#90949C] font-semibold">
                Educational Pacing
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {programming.map((project) => (
                <div
                  key={project.id}
                  className="bg-white dark:bg-[#12141A] border-2 border-slate-200 dark:border-[#232731] hover:border-[#C97B63] rounded-2xl overflow-hidden transition-all duration-200 group flex flex-col shadow-md hover:shadow-xl"
                >
                  <div className="relative aspect-[16/9] bg-black overflow-hidden flex items-center justify-center">
                    <img
                      src={project.thumbnail}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/30 pointer-events-none" />

                    <div className="absolute top-3 left-3 z-10 flex items-center gap-2">
                      <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-[#C97B63] text-white dark:text-[#0B0C0E]">
                        {project.projectNumber}
                      </span>
                      <span className="text-xs font-mono px-2 py-0.5 rounded bg-black/70 text-white">
                        {project.duration}
                      </span>
                    </div>

                    <button
                      onClick={() => onPlayProject(project)}
                      className="absolute z-10 w-16 h-16 rounded-full bg-[#C97B63] text-white dark:text-[#0B0C0E] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform"
                      aria-label={`Play ${project.title}`}
                    >
                      <Play className="w-7 h-7 fill-current ml-1" />
                    </button>
                  </div>

                  <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      <h4 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-[#ECEAE5] font-display group-hover:text-[#C97B63] transition-colors leading-tight">
                        {project.title}
                      </h4>
                      <p className="text-xs font-mono text-[#C97B63] mt-1 font-semibold">
                        {project.cutsEstimate} · {project.subtitle}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-[#20242D] text-xs">
                      <button
                        onClick={() => onPlayProject(project)}
                        className="font-bold text-[#C97B63] hover:opacity-80 text-sm flex items-center gap-1.5"
                      >
                        <Play className="w-4 h-4 fill-current" />
                        <span>Watch Video</span>
                      </button>
                      <a
                        href={project.directUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-slate-500 dark:text-[#90949C] hover:text-slate-900 dark:hover:text-white font-mono flex items-center gap-1"
                      >
                        <span>YouTube</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
